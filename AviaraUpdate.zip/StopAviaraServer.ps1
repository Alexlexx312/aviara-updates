param([Parameter(Mandatory=$true)][string]$InstallDir)
$ErrorActionPreference = 'Stop'
$serverPath = [System.IO.Path]::GetFullPath((Join-Path $InstallDir 'server.mjs'))
$processes = Get-CimInstance Win32_Process -Filter "Name = 'node.exe'" | Where-Object {
  $_.CommandLine -and $_.CommandLine.IndexOf($serverPath, [System.StringComparison]::OrdinalIgnoreCase) -ge 0
}
foreach ($process in $processes) { Stop-Process -Id $process.ProcessId -Force }
Start-Sleep -Milliseconds 600
