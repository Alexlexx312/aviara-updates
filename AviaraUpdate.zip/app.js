(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const transcript = $('transcript');
  const input = $('textInput');
  const mic = $('mic');
  const status = $('speechStatus');
  const state = {
    flaps: 0, gear: 'DOWN', heading: 0, altitude: 0, speed: 0, qnh: 1013,
    autopilot: 'OFF', autothrust: 'OFF', spoilers: 'RETRACTED', lights: 'OFF', apu: 'OFF',
    engines: 'OFF', antiIce: 'OFF', seatbelts: 'OFF', autobrake: 'OFF', parkingBrake: 'SET',
    phase: 'PARKED', foRole: localStorage.getItem('fo-role') === 'PF' ? 'PF' : 'PM', lastTarget: null, checklist: null, checklistTimer: null,
    listening: false, pttHeld: false, recognition: null, recognitionText: '', recognitionInterim: '', recorder: null, mediaStream: null, recordedChunks: [], bind: localStorage.getItem('fo-bind') || 'Space', micTest: false, micTestPassed: false, ttsTest: false, voiceError: '', voiceStartTimer: null,
    warningTimer: null, pendingWarning: false, warningRepeated: false
  };
  let aiEnabled = false, aiConfigured = false, suppressNextUserMessage = false;
  let speechQueue = [], activeUtterance = null, activeAudioSource = null, speechTimer = null;
  let activeAudioElement = null, activeAudioUrl = null;
  let calloutTimers = [];
  const clock = () => new Intl.DateTimeFormat('en', { hour: '2-digit', minute: '2-digit' }).format(new Date());
  function initStarfield() {
    const sky = $('starfield');
    if (!sky || window.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches) return;
    const stars = [];
    for (let index = 0; index < 58; index++) {
      const star = document.createElement('i'); star.className = 'flying-star';
      const duration = 10 + Math.random() * 17;
      star.style.left = `${Math.random() * 115 - 5}%`; star.style.top = `${Math.random() * 100}%`;
      star.style.animationDuration = `${duration}s`; star.style.animationDelay = `${-Math.random() * duration}s`;
      star.style.setProperty?.('--flight-x', `${-28 - Math.random() * 42}vw`);
      star.style.setProperty?.('--flight-y', `${18 + Math.random() * 37}vh`);
      star.style.setProperty?.('--star-size', `${1 + Math.random() * 2}px`);
      stars.push(star);
    }
    for (let index = 0; index < 4; index++) {
      const meteor = document.createElement('i'); meteor.className = 'shooting-star';
      const duration = 7 + Math.random() * 7;
      meteor.style.left = `${48 + Math.random() * 67}%`; meteor.style.top = `${Math.random() * 48}%`;
      meteor.style.animationDuration = `${duration}s`; meteor.style.animationDelay = `${-Math.random() * duration}s`;
      meteor.style.setProperty?.('--meteor-x', `${-105 - Math.random() * 60}vw`);
      meteor.style.setProperty?.('--meteor-y', `${42 + Math.random() * 28}vh`);
      stars.push(meteor);
    }
    sky.replaceChildren(...stars);
  }
  let toastTimer;
  function toast(message) {
    const el = $('toast'); el.textContent = message; el.classList.add('show');
    clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove('show'), 2300);
  }
  function supportedEnglishVoices() {
    return (speechSynthesis?.getVoices?.() || []).filter(voice =>
      voice.name && /^(en-US|en-GB)$/i.test(String(voice.lang || '').replace('_', '-')));
  }
  function addMessage(who, text, options = {}) {
    if (who === 'You' && suppressNextUserMessage) { suppressNextUserMessage = false; return; }
    const item = document.createElement('div'); item.className = 'msg ' + (who === 'You' ? 'user' : 'fo');
    const speaker = document.createElement('div'); speaker.className = 'speaker'; speaker.textContent = who;
    const body = document.createElement('div'); body.className = 'body' + (options.callout ? ' callout' : ''); body.textContent = text;
    const time = document.createElement('div'); time.className = 'time'; time.textContent = clock();
    item.append(speaker, body, time); transcript.appendChild(item); transcript.scrollTop = transcript.scrollHeight;
  }
  function renderState() {
    $('flaps').textContent = state.flaps === 4 ? 'FULL' : state.flaps;
    $('gear').textContent = state.gear;
    $('heading').textContent = String(state.heading).padStart(3, '0') + '°';
    $('altitude').textContent = state.altitude.toLocaleString('en-US') + ' ft';
    $('speed').textContent = state.speed + ' kt';
    $('autopilot').textContent = state.autopilot;
    $('autothrust').textContent = state.autothrust;
    $('engines').textContent = state.engines;
    $('parkingBrake').textContent = state.parkingBrake;
    $('qnh').textContent = `${state.qnh} hPa`;
    $('phase').textContent = state.phase;
    $('bindValue').textContent = state.bind === 'Space' ? 'SPACE' : state.bind.replace('Key', '').replace('Digit', '');
    $('bindLabel').textContent = state.bind === 'Space' ? 'SPACE' : state.bind.replace('Key', '').replace('Digit', '');
  }
  function pickVoice() {
    if (!window.speechSynthesis || !$('voiceSelect')) return;
    const voices = supportedEnglishVoices();
    const maleHints = /david|mark|guy|daniel|james|george|ryan|aaron|andrew|brian|christopher|matthew|thomas|oliver|eric|roger|male/i;
    const select = $('voiceSelect');
    const current = select.value;
    const savedLocal = localStorage.getItem('fo-local-voice');
    const savedV2 = localStorage.getItem('fo-voice-v2');
    const previous = current && !current.startsWith('edge:') && current !== 'Loading installed voices…'
      ? current : (savedLocal || (savedV2 && !savedV2.startsWith('edge:') ? savedV2 : ''));
    select.replaceChildren();
    if (!voices.length) {
      select.append(new Option('No English (US/UK) voices found yet', ''));
      return;
    }
    voices.sort((a, b) => Number(a.localService === false) - Number(b.localService === false)
      || a.lang.localeCompare(b.lang) || a.name.localeCompare(b.name));
    for (const voice of voices) {
      const kind = voice.localService === false ? 'Online' : 'Local';
      select.append(new Option(`${voice.name} · ${voice.lang} · ${kind}`, voice.name));
    }
    const available = voices.map(voice => voice.name);
    const preferred = available.find(name => /microsoft david/i.test(name))
      || available.find(name => /microsoft mark/i.test(name))
      || voices.find(voice => voice.localService !== false)?.name || voices[0].name;
    select.value = available.includes(previous) ? previous : preferred;
  }
  function finishSpeech(entry) {
    if (speechQueue[0] !== entry) return;
    clearTimeout(speechTimer); speechTimer = null; activeUtterance = null;
    activeAudioElement = null;
    if (activeAudioUrl) URL.revokeObjectURL(activeAudioUrl);
    activeAudioUrl = null;
    speechQueue.shift();
    entry.onComplete?.();
    if (state.ttsTest) { state.ttsTest = false; $('speechStatus').textContent = 'Voice ready'; $('voiceHelp').textContent = 'Voice test finished.'; }
    setTimeout(playNextSpeech, 80);
  }
  function retrySpeech(entry, reason) {
    if (speechQueue[0] !== entry) return;
    clearTimeout(speechTimer); speechTimer = null; activeUtterance = null;
    try { activeAudioSource?.stop(); } catch (_) { }
    activeAudioSource = null;
    try { activeAudioElement?.pause(); } catch (_) { }
    activeAudioElement = null;
    if (activeAudioUrl) URL.revokeObjectURL(activeAudioUrl);
    activeAudioUrl = null;
    if (entry.retries < 1 && $('speakToggle').checked) {
      entry.retries++;
      const voices = supportedEnglishVoices();
      const selected = voices.find(voice => voice.name === $('voiceSelect').value);
      const localEnglish = voices.find(voice => voice.localService !== false);
      if (selected?.localService === false && localEnglish) {
        entry.fallbackVoice = localEnglish.name;
        $('voiceHelp').textContent = `Online voice did not respond; retrying with ${localEnglish.name}.`;
      }
      try { speechSynthesis?.cancel(); } catch (_) { }
      setTimeout(playNextSpeech, 180);
      return;
    }
    if (state.ttsTest) { state.ttsTest = false; $('speechStatus').textContent = 'Voice unavailable'; $('voiceHelp').textContent = `No audio played (${reason}). Check Windows sound output and install an English (US) or English (UK) voice.`; }
    speechQueue.shift(); entry.onComplete?.(); setTimeout(playNextSpeech, 80);
  }
  function playNextSpeech() {
    if (activeUtterance || !speechQueue.length || !$('speakToggle').checked) return;
    const entry = speechQueue[0];
    playLocalSpeech(entry);
  }
  function playLocalSpeech(entry) {
    if (speechQueue[0] !== entry) return;
    if (!window.speechSynthesis) { retrySpeech(entry, 'speech service missing'); return; }
    try {
      const voices = supportedEnglishVoices();
      const chosen = voices.find(voice => voice.name === entry.fallbackVoice)
        || voices.find(voice => voice.name === $('voiceSelect').value)
        || voices.find(voice => voice.localService !== false) || voices[0] || null;
      if (!chosen && voices.length) pickVoice();
      if (!chosen) { retrySpeech(entry, 'no English (US/UK) voice available'); return; }
      const utterance = new SpeechSynthesisUtterance(entry.text);
      utterance.voice = chosen; utterance.lang = chosen?.lang || 'en-US';
      utterance.rate = entry.options.callout ? 0.90 : 0.92; utterance.pitch = 0.98; utterance.volume = 1;
      activeUtterance = utterance;
      utterance.onstart = () => {
        if (activeUtterance !== utterance) return;
        clearTimeout(speechTimer);
        if (state.ttsTest) { $('speechStatus').textContent = 'Speaking test…'; $('voiceHelp').textContent = 'Voice output started. You should hear the test phrase.'; }
        speechTimer = setTimeout(() => retrySpeech(entry, 'voice stopped responding'), Math.max(12000, Math.min(60000, entry.text.length * 180)));
      };
      utterance.onend = () => finishSpeech(entry);
      utterance.onerror = event => retrySpeech(entry, event.error || 'voice playback error');
      speechTimer = setTimeout(() => retrySpeech(entry, 'voice did not start'), 4000);
      speechSynthesis.resume?.(); speechSynthesis.speak(utterance);
    } catch (error) { retrySpeech(entry, error.message || 'voice playback error'); }
  }
  function stopSpeech() {
    speechQueue = []; activeUtterance = null; clearTimeout(speechTimer); speechTimer = null;
    try { activeAudioSource?.stop(); } catch (_) { }
    activeAudioSource = null;
    try { activeAudioElement?.pause(); } catch (_) { }
    activeAudioElement = null;
    if (activeAudioUrl) URL.revokeObjectURL(activeAudioUrl);
    activeAudioUrl = null;
    try { speechSynthesis?.cancel(); } catch (_) { }
  }
  function speechSegments(text) {
    const parts = String(text).match(/[^,;.!?]+[,;.!?]?/g) || [String(text)];
    const segments = []; let current = '';
    for (const raw of parts) {
      const part = raw.trim(); if (!part) continue;
      if (current && current.length + part.length + 1 > 112) { segments.push(current); current = ''; }
      current = current ? `${current} ${part}` : part;
    }
    if (current) segments.push(current);
    return segments.length ? segments : [String(text)];
  }
  function speak(text, options = {}, onComplete = null) {
    if (!$('speakToggle').checked) { onComplete?.(); return; }
    const segments = speechSegments(text);
    speechQueue.push(...segments.map((segment, index) => ({ text: segment, options, retries: 0, onComplete: index === segments.length - 1 ? onComplete : null }))); playNextSpeech();
  }
  function reply(text, options = {}, onComplete = null) { state.lastReply = text; addMessage('First Officer', text, options); speak(text, options, onComplete); }
  function pauseChecklist() {
    if (!state.checklist || state.checklist.paused || state.checklist.waiting) return;
    if (state.checklistTimer) clearTimeout(state.checklistTimer);
    state.checklistTimer = null; state.checklist.paused = true; renderChecklist();
    toast('Checklist paused. Say “Resume checklist” when ready.');
  }
  function finishChecklist() {
    if (!state.checklist) return;
    const name = state.checklist.name;
    state.checklist = null; state.checklistTimer = null; renderChecklist();
    reply(`${name} checklist complete. Demo steps only; nothing was sent to the simulator.`, { callout: true });
  }
  function checklistStep() {
    const flow = state.checklist;
    if (!flow || flow.paused) return;
    if (flow.index >= flow.steps.length) return finishChecklist();
    const step = flow.steps[flow.index++];
    flow.current = step.item;
    flow.currentExpected = step.responses;
    flow.waiting = true;
    renderChecklist();
    reply(flow.current, { callout: true });
  }
  const flows = {
    'preflight': [
      { item: 'Parking brake', responses: ['set', 'on', 'checked'] }, { item: 'Batteries', responses: ['on', 'checked'] },
      { item: 'ADIRS', responses: ['set', 'checked'] }, { item: 'Fuel pumps', responses: ['on', 'checked'] },
      { item: 'Flight instruments', responses: ['checked', 'set', 'normal'] }
    ],
    'before start': [
      { item: 'Doors', responses: ['checked', 'closed', 'secured', 'latched'] }, { item: 'Fuel quantity', responses: ['checked', 'sufficient', 'adequate'] },
      { item: 'APU', responses: ['available', 'ready'] }, { item: 'Beacon', responses: ['on', 'set'] }
    ],
    'after start': [
      { item: 'Engine parameters', responses: ['checked', 'normal', 'stable'] }, { item: 'Anti-ice', responses: ['as required', 'off', 'on', 'checked'] },
      { item: 'Flight controls', responses: ['checked', 'free'] }, { item: 'Flaps', responses: ['checked', 'set'] }
    ],
    'taxi': [
      { item: 'Brakes', responses: ['checked', 'normal'] }, { item: 'Flight controls', responses: ['checked', 'free'] },
      { item: 'Nose wheel steering', responses: ['checked', 'normal'] }, { item: 'Taxi lights', responses: ['set', 'on'] }
    ],
    'before takeoff': [
      { item: 'Cabin', responses: ['ready', 'secure', 'checked'] }, { item: 'Takeoff configuration', responses: ['checked', 'set'] },
      { item: 'Flaps', responses: ['set', 'checked'] }, { item: 'Spoilers', responses: ['armed', 'set'] }
    ],
    'climb': [
      { item: 'Landing gear', responses: ['up', 'retracted'] }, { item: 'Flaps', responses: ['retracted', 'clean', 'zero'] },
      { item: 'Autopilot', responses: ['on', 'engaged', 'set'] }
    ],
    'cruise': [
      { item: 'Cruise altitude', responses: ['checked', 'set'] }, { item: 'Pressurization', responses: ['checked', 'normal'] },
      { item: 'Fuel balance', responses: ['checked', 'balanced', 'normal'] }
    ],
    'descent': [
      { item: 'Descent briefing', responses: ['complete', 'checked'] }, { item: 'Arrival information', responses: ['set', 'checked'] },
      { item: 'Altimeters', responses: ['set', 'checked'] }
    ],
    'approach': [
      { item: 'Approach briefing', responses: ['complete', 'checked'] }, { item: 'Seat belts', responses: ['on', 'checked'] },
      { item: 'Landing performance', responses: ['checked', 'set'] }, { item: 'Landing gear', responses: ['down', 'checked', 'three green'] }
    ],
    'landing': [
      { item: 'Landing gear', responses: ['down', 'checked', 'three green'] }, { item: 'Flaps', responses: ['set', 'full', 'checked'] },
      { item: 'Spoilers', responses: ['armed', 'checked'] }
    ],
    'after landing': [
      { item: 'Spoilers', responses: ['disarmed', 'off'] }, { item: 'Flaps', responses: ['retracted', 'zero'] },
      { item: 'Taxi lights', responses: ['on', 'set'] }
    ],
    'shutdown': [
      { item: 'Parking brake', responses: ['set', 'on'] }, { item: 'Engines', responses: ['shut down', 'off'] },
      { item: 'Seat belts', responses: ['off'] }
    ]
  };
  function chooseFlow(text) {
    if (/preflight|before flight|cockpit preparation|cold and dark/.test(text)) return 'preflight';
    if (/before start|pre.?start/.test(text)) return 'before start';
    if (/after start/.test(text)) return 'after start';
    if (/taxi/.test(text)) return 'taxi';
    if (/before takeoff|pre.?takeoff|takeoff checklist/.test(text)) return 'before takeoff';
    if (/\bclimb/.test(text)) return 'climb';
    if (/\bcruise/.test(text)) return 'cruise';
    if (/descent/.test(text)) return 'descent';
    if (/approach/.test(text)) return 'approach';
    if (/after landing/.test(text)) return 'after landing';
    if (/landing/.test(text)) return 'landing';
    if (/shutdown|shut down/.test(text)) return 'shutdown';
    return null;
  }
  function renderChecklist() {
    const panel = $('checklistPanel');
    if (!panel) return;
    const flow = state.checklist;
    panel.hidden = !flow;
    if (!flow) return;
    $('checklistName').textContent = flow.name.toUpperCase();
    $('checklistCount').textContent = `${flow.completed || 0} / ${flow.steps.length}`;
    $('checklistCurrent').textContent = flow.current || 'Preparing the next item…';
    $('checklistStatus').textContent = flow.paused ? 'PAUSED' : flow.correctionPending ? 'CORRECTION' : flow.waiting ? 'AWAITING RESPONSE' : 'READING';
    const progress = $('checklistProgress');
    if (progress?.style) progress.style.width = `${Math.min(100, 100 * (flow.completed || 0) / flow.steps.length)}%`;
  }
  function runChecklist(name, mode = 'step') {
    if (!flows[name]) { reply('I don’t have that checklist in this demo yet.'); return; }
    if (state.checklistTimer) clearTimeout(state.checklistTimer);
    state.checklist = { name, steps: flows[name], index: 0, mode: 'step', paused: false, waiting: false, current: '', correctionPending: '', corrections: [] };
    const flow = state.checklist;
    const introStartedAt = Date.now();
    reply(`Starting the ${name} checklist.`, { callout: true }, () => {
      if (state.checklist === flow && !flow.paused && flow.index === 0 && !flow.waiting) {
        const minimumIntroTime = 2600;
        const remaining = Math.max(450, minimumIntroTime - (Date.now() - introStartedAt));
        state.checklistTimer = setTimeout(checklistStep, remaining);
      }
    });
    renderChecklist();
  }
  function resumeChecklist() {
    if (!state.checklist || !state.checklist.paused) { reply('There is no paused checklist.'); return; }
    state.checklist.paused = false; renderChecklist(); reply('Resuming the checklist.');
    state.checklistTimer = setTimeout(checklistStep, 600);
  }
  function ackChecklist() {
    const flow = state.checklist;
    if (!flow || flow.mode !== 'step' || !flow.waiting) return false;
    flow.waiting = false; flow.correctionPending = ''; state.checklistTimer = setTimeout(checklistStep, 350); renderChecklist(); return true;
  }
  function handleChecklistResponse(raw, text) {
    const flow = state.checklist;
    if (!flow) return false;
    if (/\b(?:stop|cancel)\b.*checklist|\b(?:stop|cancel)\s+(?:it|this)\b/.test(text)) {
      if (state.checklistTimer) clearTimeout(state.checklistTimer);
      state.checklist = null; state.checklistTimer = null; renderChecklist(); reply('Checklist stopped.'); return true;
    }
    if (/\b(?:resume|continue)\b.*checklist/.test(text)) { resumeChecklist(); return true; }
    if (/\b(?:pause)\b.*checklist/.test(text)) { pauseChecklist(); reply('Checklist paused.'); return true; }
    if (flow.paused) { reply('The checklist is paused. Say “resume checklist” when ready.'); return true; }
    if (!flow.waiting) return false;
    const positive = /^(?:check|checked|correct|right|yes|yeah|yep|yup|affirmative|confirmed|verified|good|looks good|all good|all set|okay|ok|roger|next item|next one|continue|that is correct|that s correct|thats correct|that is right|thats right)$/;
    const negative = /\b(?:no|nope|not correct|incorrect|wrong|negative|not right|that is not right|that s not right|thats not right|not (?:on|off|up|down|armed|retracted|available|ready|set|checked|clear|complete|closed|in position)|unavailable|isnt correct|doesnt match|does not match|needs? correction)\b/;
    const answer = text.replace(/\bthat’s\b/g, 'that s').trim();
    const expected = flow.currentExpected || [];
    const confirmsExpected = expected.some(term => term.includes(' ') ? answer.includes(term) : answer.split(/\s+/).includes(term));
    const statusOnly = /^(?:available|ready|set|on|off|checked|check|clear|complete|completed|armed|disarmed|retracted|up|down|zero|clean|closed|secured|latched|sufficient|adequate|normal|stable|free|engaged|full|balanced|three green|3 green)(?:\s+(?:for takeoff|when instructed|as required|as directed|as instructed|on schedule))?$/;
    if (/\b(?:repeat|say again|one more time)\b/.test(text)) {
      if (flow.correctionPending === 'confirm') { flow.correctionPending = 'input'; renderChecklist(); reply('Okay. Tell me the correct indication again.'); }
      else reply(flow.current);
      return true;
    }
    if (flow.correctionPending === 'input') {
      const correction = text || raw;
      flow.corrections.push({ item: flow.current, correction }); flow.correctionText = correction; flow.correctionPending = 'confirm'; renderChecklist();
      reply(`I heard: ${correction}. Is that right?`); return true;
    }
    if (flow.correctionPending === 'confirm') {
      if (positive.test(answer)) { flow.waiting = false; flow.correctionPending = ''; flow.completed = (flow.completed || 0) + 1; renderChecklist(); reply('Correction noted. Moving to the next item.'); state.checklistTimer = setTimeout(checklistStep, 450); return true; }
      if (negative.test(text)) { flow.correctionPending = 'input'; renderChecklist(); reply('Okay. Tell me the correct indication again.'); return true; }
      reply('Sorry, I missed that. Is the correction right, or should I read it again?'); return true;
    }
    if (negative.test(text) || (statusOnly.test(answer) && !confirmsExpected)) {
      const spokenState = answer.match(/\b(?:available|ready|set|on|off|checked|clear|complete|armed|disarmed|retracted|up|down|zero|clean|closed|secured|latched|sufficient|adequate|normal|stable|free|engaged|full|balanced|three green|3 green)\b/);
      if (spokenState) {
        flow.correctionText = answer; flow.corrections.push({ item: flow.current, correction: answer }); flow.correctionPending = 'confirm'; renderChecklist();
        reply(`I heard: ${answer}. Is that right?`); return true;
      }
      flow.correctionPending = 'input'; renderChecklist(); reply('What do you see?'); return true;
    }
    if (positive.test(answer) || confirmsExpected) { flow.waiting = false; flow.completed = (flow.completed || 0) + 1; renderChecklist(); state.checklistTimer = setTimeout(checklistStep, 350); return true; }
    reply('Sorry, I didn’t catch that.'); return true;
  }
  function wordsToNumbers(text) {
    const map = { zero: '0', oh: '0', one: '1', won: '1', two: '2', three: '3', tree: '3', four: '4', five: '5', fife: '5', six: '6', seven: '7', eight: '8', nine: '9', ten: '10', eleven: '11', twelve: '12', thirteen: '13', fourteen: '14', fifteen: '15', sixteen: '16', seventeen: '17', eighteen: '18', nineteen: '19', twenty: '20', thirty: '30', forty: '40', fifty: '50', sixty: '60', seventy: '70', eighty: '80', ninety: '90', hundred: '100', thousand: '1000' };
    return text.replace(/\b(zero|oh|one|won|two|three|tree|four|five|fife|six|seven|eight|nine|ten|twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety|hundred|thousand)\b/g, w => map[w])
      .replace(/\b(eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen)\b/g, w => map[w])
      .replace(/\b(\d{1,2})\s+1000\b/g, (_, n) => String(Number(n) * 1000))
      .replace(/\b(\d{1,2})\s+100\b/g, (_, n) => String(Number(n) * 100))
      .replace(/\b(\d{1,2}000)\s+(?:and\s+)?(\d{1,3})\b/g, (_, thousands, rest) => String(Number(thousands) + Number(rest)))
      .replace(/\b(\d{1,2}00)\s+(?:and\s+)?(\d{1,2})\b/g, (_, hundreds, rest) => String(Number(hundreds) + Number(rest)))
      .replace(/\b(\d)\s+(\d)\s+(\d)\s+(\d)\b/g, '$1$2$3$4')
      .replace(/\b(\d)\s+(\d)\s+(\d)\b/g, '$1$2$3')
      .replace(/\b(\d)\s+(\d{2})\b/g, '$1$2');
  }
  function numberAfter(text, terms) {
    const re = new RegExp(`(?:${terms})\\s*(?:to|at|of|is|set)?\\s*(-?\\d[\\d,]*(?:\\.\\d+)?)`, 'i');
    const match = text.match(re); return match ? Number(match[1].replace(/,/g, '')) : null;
  }
  function has(text, regex) { return regex.test(text); }
  function cancelWarning() { if (state.warningTimer) clearTimeout(state.warningTimer); state.warningTimer = null; state.pendingWarning = false; state.warningRepeated = false; }
  function triggerWarning() {
    cancelWarning(); state.pendingWarning = true; state.warningRepeated = false;
    const text = 'Captain, important demo warning: landing configuration is incomplete. Check gear and flaps.';
    reply(text, { callout: true });
    state.warningTimer = setTimeout(() => {
      if (!state.pendingWarning || state.warningRepeated) return;
      state.warningRepeated = true; reply('Repeating: landing configuration is incomplete. Check gear and flaps.', { callout: true });
      state.warningTimer = setTimeout(cancelWarning, 6500);
    }, 5000);
  }
  function calloutSequence() {
    cancelCalloutSequence(false);
    pauseChecklist(); state.phase = 'TAKEOFF DEMO'; renderState();
    const calls = [['One hundred knots.', 0], ['V1.', 1450], ['Rotate.', 2850], ['V2.', 3850], ['Positive climb.', 4950], ['Gear up.', 6500]];
    calls.forEach(([text, delay]) => calloutTimers.push(setTimeout(() => { if (state.phase === 'TAKEOFF DEMO') reply(text, { callout: true }); }, delay)));
    calloutTimers.push(setTimeout(() => { if (state.phase === 'TAKEOFF DEMO') { state.phase = 'CLIMB DEMO'; $('progress').style.width = '24%'; renderState(); } calloutTimers = []; }, 7800));
  }
  function cancelCalloutSequence(resetPhase = true) {
    for (const timer of calloutTimers) clearTimeout(timer);
    calloutTimers = [];
    if (resetPhase && state.phase === 'TAKEOFF DEMO') { state.phase = 'PARKED'; const progress = $('progress'); if (progress?.style) progress.style.width = '0%'; renderState(); }
  }
  function normalize(raw) {
    const spoken = raw.toLowerCase().replace(/[’']/g, '').replace(/[.,!?]/g, ' ')
      .replace(/\b(?:flats?|flaps?|flabs?|flab)\b/g, 'flaps')
      .replace(/\b(?:flips?|flib|flibs?|filip|fillip|philip)\s+(?:one|won|swan|1)\b/g, 'flaps one')
      .replace(/\b(?:flaps?)\s+(?:setting|position)\b/g, 'flaps')
      .replace(/\b(?:year|ear|deer|geer)\s+(?=(?:up|down|retract|extend|raise|lower)\b)/g, 'gear ')
      .replace(/\b(?:hedging|heding|hedding|head ing|headin|headings|heading bug|heading bug set)\b/g, 'heading')
      .replace(/\b(?:attitude|altitute|altitiude|altitood)\b/g, 'altitude')
      .replace(/\b(?:auto pilot|auto pile it|autopile it|auto pie lot|autopilot)\b/g, 'autopilot')
      .replace(/\b(?:auto thrust|auto trust|auto throttle|autothrottle|a thrust|a thr|a slash thr)\b/g, 'autothrust')
      .replace(/\b(?:a p u|a p you|ap you|a p y)\b/g, 'apu')
      .replace(/\b(?:spoliers|spoiller|spoilerss|spoyler|spoylers|speed break|speed breaks|speed brake)\b/g, 'spoilers')
      .replace(/\b(?:parkin break|parking breaks|parking break|park break|park brake)\b/g, 'parking brake')
      .replace(/\b(?:flap one|flaps won|flap won|flips? one|flips? won|flips? 1|filip swan|fillip swan|philip swan)\b/g, 'flaps one')
      .replace(/\b(?:flap two|flaps to|flaps too)\b/g, 'flaps two')
      .replace(/\b(?:gear up|year up|gear down|year down)\b/g, match => match.replace(/^year/, 'gear'))
      .replace(/\b(?:autobreak|auto break|auto brake|auto breaks|auto brakes|auto breakes)\b/g, 'autobrake')
      .replace(/\b(?:take off)\b/g, 'takeoff')
      .replace(/\b(?:seat belt|seat belts|seatbelt|seatbelts)\b/g, 'seat belts')
      .replace(/\b(?:q and h|q and age|cue en age|cue and h|qnh)\b/g, 'qnh')
      .replace(/\b(?:a valuable|a veilable|a vailable|a vail able|avail|avialable|avaiable|availble|avalable|available)\b/g, 'available')
      .replace(/\b(?:set|select|put|configure)\s+(?:the\s+)?flaps?\s+(?:to|at|position|setting)\s+/g, 'flaps ')
      .replace(/\bflaps?\s+(?:set|at|position|setting)\s+(?:to\s+)?/g, 'flaps ')
      .replace(/\b(one|two|three|four|full)\s+flaps?\b/g, 'flaps $1')
      .replace(/\s+/g, ' ').trim();
    return wordsToNumbers(spoken)
      .replace(/\bflight level\s+(\d)\s+(\d)\s+(\d)\b/g, (_, a, b, c) => String(Number(a + b + c) * 100))
      .replace(/\bflight level\s+(\d{2,3})\b/g, (_, n) => String(Number(n) * 100))
      .replace(/\b3 green\b/g, 'three green')
      .replace(/\bdegrees?\b/g, '').replace(/\bfeet\b/g, '').replace(/\bknots?\b/g, '');
  }
  function setNumber(target, value) {
    if (!Number.isFinite(value)) return false;
    if (target === 'heading') { state.heading = ((Math.round(value) % 360) + 360) % 360; }
    if (target === 'altitude') {
      if (value < 0 || value > 60000) { reply('Please repeat the altitude, from zero to sixty thousand feet.'); return false; }
      state.altitude = Math.round(value);
    }
    if (target === 'speed') {
      if (value < 0 || value > 450) { reply('Please repeat the selected speed, up to four hundred fifty knots.'); return false; }
      state.speed = Math.round(value);
    }
    state.lastTarget = target; renderState();
    const label = target === 'heading' ? `Heading ${spokenDigits(state.heading, true)} set.` : target === 'altitude' ? `${spokenAltitude(state.altitude)} set.` : `Speed ${spokenDigits(state.speed)} set.`;
    reply(label); return true;
  }
  function spokenDigits(value, padHeading = false) {
    const names = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine'];
    const digits = String(Math.max(0, Math.round(value)));
    return (padHeading ? digits.padStart(3, '0') : digits).split('').map(digit => names[Number(digit)]).join(' ');
  }
  function spokenAltitude(value) {
    const thousands = Math.floor(value / 1000), remainder = value % 1000;
    const small = ['', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen'];
    if (thousands && remainder === 0 && thousands < small.length) return `${small[thousands]} thousand`;
    if (thousands && remainder === 0) return `${spokenDigits(thousands)} thousand`;
    if (value === 0) return 'zero';
    return value.toLocaleString('en-US');
  }
  function handleCommand(raw) {
    if (!raw.trim()) return;
    if (state.pendingWarning && /\b(?:acknowledge|acknowledged|understood|check|checked|correct)\b/i.test(raw)) cancelWarning();
    addMessage('You', raw);
    const text = normalize(raw);
    if (/\b(?:stop|cancel|pause)\b.*\bcallouts?\b|\b(?:stop|cancel)\s+(?:takeoff )?demo\b/.test(text)) {
      cancelCalloutSequence(); stopSpeech(); reply('Callouts stopped.'); return;
    }
    if (/\b(?:play|run|start|test|repeat)\b.*\b(?:takeoff )?(?:callouts?|call out demo)\b|\btakeoff callouts?\b/.test(text)) {
      calloutSequence(); return;
    }
    if (/\b(?:what|which|list|available).{0,25}\bcallouts?\b|\bcallouts?\s+(?:available|list)\b/.test(text)) {
      reply('The demo takeoff sequence includes one hundred knots, V1, Rotate, V2, Positive climb, and Gear up. These are scripted examples, not live callouts.'); return;
    }
    if (handleChecklistResponse(raw, text)) return;
    if (/\b(?:say again|repeat that|repeat last|what was that)\b/.test(text) && state.lastReply) { reply(state.lastReply); return; }
    if (/\b(?:available checklists|which checklists|what checklists|list checklists|checklist options)\b/.test(text)) {
      reply(`Available demo checklists: ${Object.keys(flows).join(', ')}.`); return;
    }
    if (/^(?:available|what is available|what checklists are available)$/.test(text)) {
      reply(`Available demo checklists: ${Object.keys(flows).join(', ')}.`); return;
    }
    if (aiEnabled && aiConfigured) {
      askAI(raw); return;
    }
    const flowName = chooseFlow(text);
    if (/\b(?:resume|continue)\b.*checklist/.test(text)) { resumeChecklist(); return; }
    if (/\b(?:stop|cancel|pause)\b.*checklist/.test(text)) { if (state.checklist) { pauseChecklist(); reply('Checklist paused.'); } else reply('No checklist is active.'); return; }
    if (/\b(?:checked|check|next item|next one|continue)\b/.test(text) && ackChecklist()) { reply('Check.'); return; }
    if (flowName && /\b(?:checklist|flow|checks)\b/.test(text)) { runChecklist(flowName, 'step'); return; }

    if (/\bflaps?\b|\bflap lever\b|\bconfiguration\b/.test(text)) {
      const m = text.match(/(?:flaps?|flap lever|configuration)\s*(?:to|at|on|position)?\s*(full|\d)/);
      if (m) {
        const setting = m[1] === 'full' ? 4 : Number(m[1]);
        if (setting > 4) { reply('Please repeat the flap setting: zero, one, two, three or full.'); return; }
        state.flaps = setting; renderState(); reply(`Flaps ${state.flaps === 4 ? 'full' : spokenDigits(state.flaps)}.`); return;
      }
      if (/flaps?\s*(?:up|zero|retract|clean)/.test(text)) { state.flaps = 0; renderState(); reply('Flaps zero.'); return; }
      reply('Which flap setting would you like?'); return;
    }
    if (/\b(?:landing )?gear\b/.test(text)) {
      if (/\b(?:up|retract|raise)\b/.test(text)) { state.gear = 'UP'; renderState(); reply('Gear up.'); return; }
      if (/\b(?:down|lower|extend)\b/.test(text)) { state.gear = 'DOWN'; renderState(); reply('Gear down.'); return; }
      reply(`Landing gear is ${state.gear.toLowerCase()} in the demo.`); return;
    }
    let value;
    if (/\b(?:heading|hdg)\b/.test(text) && /\b(?:left|right)\b/.test(text)) {
      const m = text.match(/\b(left|right)\s+(?:heading\s+)?(\d{1,3})\b/);
      if (m) { const delta = Number(m[2]); setNumber('heading', state.heading + (m[1] === 'right' ? delta : -delta)); return; }
    }
    if (/\b(?:heading|hdg|heading bug|selected heading)\b/.test(text) && (value = numberAfter(text, 'heading|hdg|heading bug|selected heading')) !== null) {
      if (value < 0 || value > 360) { reply('Please repeat the selected heading, from zero to three six zero.'); return; }
      setNumber('heading', value); return;
    }
    const verticalTarget = text.match(/\b(?:climb and maintain|descend and maintain|maintain|climb to|descend to|hold altitude)\s+(-?\d[\d,]*)/);
    if (verticalTarget) { setNumber('altitude', Number(verticalTarget[1].replace(/,/g, ''))); return; }
    if (/\b(?:altitude|alt|selected altitude|flight level|level)\b/.test(text) && (value = numberAfter(text, 'altitude|alt|selected altitude|level')) !== null) { setNumber('altitude', value); return; }
    if (/\b(?:speed|airspeed|selected speed)\b/.test(text) && (value = numberAfter(text, 'speed|airspeed|selected speed')) !== null) { setNumber('speed', value); return; }
    const follow = text.match(/\b(?:make that|change it to|set it to|and make it|and set it to)\s*(-?\d[\d,]*)/);
    if (follow && state.lastTarget) { setNumber(state.lastTarget, Number(follow[1].replace(/,/g, ''))); return; }
    if (/\b(?:autopilot|ap1|ap2)\b/.test(text) && /\b(?:on|engage|activate)\b/.test(text)) { state.autopilot = /ap2/.test(text) ? 'AP2' : 'AP1'; renderState(); reply(`${state.autopilot} engaged.`); return; }
    if (/\b(?:autopilot|ap1|ap2)\b/.test(text) && /\b(?:off|disconnect|disengage)\b/.test(text)) { state.autopilot = 'OFF'; renderState(); reply('Autopilot off.'); return; }
    if (/\b(?:autothrust|a th|a slash thr)\b/.test(text)) {
      if (/\b(?:on|engage|activate|arm)\b/.test(text)) state.autothrust = 'ON';
      else if (/\b(?:off|disconnect|disengage)\b/.test(text)) state.autothrust = 'OFF';
      else { reply(`Autothrust ${state.autothrust.toLowerCase()}.`); return; }
      renderState(); reply(`Autothrust ${state.autothrust.toLowerCase()}.`); return;
    }
    if (/\b(?:engines?|engine master)\b/.test(text)) {
      if (/\b(?:start|on|run)\b/.test(text)) state.engines = 'ON';
      else if (/\b(?:stop|off|shut down|shutdown|cut)\b/.test(text) || (/\bshut\b/.test(text) && /\bdown\b/.test(text))) state.engines = 'OFF';
      else { reply(`Engines ${state.engines.toLowerCase()}.`); return; }
      renderState(); reply(`Engines ${state.engines.toLowerCase()}.`); return;
    }
    if (/\b(?:anti ice|antiice|engine anti ice|wing anti ice)\b/.test(text)) {
      if (/\b(?:on|set|activate)\b/.test(text)) state.antiIce = 'ON';
      else if (/\b(?:off|deactivate)\b/.test(text)) state.antiIce = 'OFF';
      else { reply(`Anti-ice ${state.antiIce.toLowerCase()}.`); return; }
      reply(`Anti-ice ${state.antiIce.toLowerCase()}.`); return;
    }
    if (/\b(?:seat ?belt signs?|fasten seat belts?|no smoking signs?)\b/.test(text)) {
      if (/\b(?:on|set|on)\b/.test(text)) state.seatbelts = 'ON';
      else if (/\b(?:off|turn off)\b/.test(text)) state.seatbelts = 'OFF';
      else { reply(`Seat-belt signs ${state.seatbelts.toLowerCase()}.`); return; }
      reply(`Seat-belt signs ${state.seatbelts.toLowerCase()}.`); return;
    }
    if (/\b(?:autobrake|auto brake)\b/.test(text)) {
      const setting = text.match(/\b(?:off|low|med|medium|max)\b/);
      if (!setting) { reply(`Autobrake ${state.autobrake.toLowerCase()}.`); return; }
      state.autobrake = setting[0] === 'medium' ? 'MED' : setting[0].toUpperCase(); reply(`Autobrake ${state.autobrake}.`); return;
    }
    if (/\b(?:qnh|baro|barometric|altimeter(?: setting)?)\b/.test(text) && (value = numberAfter(text, 'qnh|baro|barometric|altimeter(?: setting)?')) !== null) {
      if (value < 800 || value > 1100) { reply('Please repeat the QNH value in hectopascals.'); return; }
      state.qnh = Math.round(value); renderState(); reply(`QNH ${spokenDigits(state.qnh)} set.`); return;
    }
    if (/\b(?:arm|deploy)\b.*\b(?:spoilers?|speed brakes?)\b/.test(text) || /\bspoilers?\s+(?:to\s+)?armed\b/.test(text)) { state.spoilers = 'ARMED'; reply('Spoilers armed.'); return; }
    if (/\b(?:disarm|retract|stow)\b.*\b(?:spoilers?|speed brakes?)\b/.test(text) || /\bspoilers?\s+(?:to\s+)?(?:off|retracted)\b/.test(text)) { state.spoilers = 'RETRACTED'; reply('Spoilers retracted.'); return; }
    if (/\b(?:parking brake|park brake)\b/.test(text)) { if (/\b(?:release|off|disengage)\b/.test(text)) state.parkingBrake = 'RELEASED'; else if (/\b(?:set|on|engage)\b/.test(text)) state.parkingBrake = 'SET'; reply(`Parking brake ${state.parkingBrake.toLowerCase()}.`); return; }
    if (/\b(?:apu)\b/.test(text)) { if (/\b(?:start|on|available)\b/.test(text)) { state.apu = 'ON'; reply('APU on.'); } else if (/\b(?:stop|off|shut down)\b/.test(text)) { state.apu = 'OFF'; reply('APU off.'); } else reply(`APU ${state.apu.toLowerCase()}.`); return; }
    if (/\b(?:landing lights|taxi lights|strobe lights|beacon|lights)\b/.test(text)) { const action = /\b(?:on|set|turn on)\b/.test(text) ? 'ON' : /\b(?:off|turn off)\b/.test(text) ? 'OFF' : null; if (action) { state.lights = action; reply(`Lights ${action.toLowerCase()}.`); } else reply(`Lights ${state.lights.toLowerCase()}.`); return; }

    if (/\b(?:what is|what's|whats|tell me|report|check|read back).*(?:status|state|configuration|setup)\b/.test(text) || /\bstatus report\b/.test(text)) {
      reply(`Demo status: ${state.phase.toLowerCase()}; I’m assigned ${state.foRole === 'PF' ? 'Pilot Flying' : 'Pilot Monitoring'} for this sector; engines ${state.engines.toLowerCase()}; flaps ${state.flaps === 4 ? 'full' : state.flaps}; gear ${state.gear.toLowerCase()}; heading ${state.heading}; altitude ${state.altitude.toLocaleString('en-US')} feet; selected speed ${state.speed} knots; autopilot ${state.autopilot.toLowerCase()}; autothrust ${state.autothrust.toLowerCase()}; QNH ${state.qnh}.`); return;
    }
    if (/\b(?:what is|what's|whats|how high|report).*(?:altitude|height)\b/.test(text)) { reply(`We’re at ${state.altitude.toLocaleString('en-US')} feet in this demo.`); return; }
    if (/\b(?:what is|what's|whats|report).*(?:heading|direction)\b/.test(text)) { reply(`The selected heading is ${state.heading} degrees in the demo.`); return; }
    if (/\b(?:what is|what's|whats|report).*(?:speed|airspeed)\b/.test(text)) { reply(`The demo speed is ${state.speed} knots.`); return; }
    if (/\b(?:what phase|where are we|flight phase)\b/.test(text)) { reply(`We’re in the ${state.phase.toLowerCase()} phase in the demo.`); return; }
    if (/\b(?:weather|wind|atis|destination|arrival airport|next waypoint)\b/.test(text)) { reply('I don’t have live flight or weather data in this disconnected demo.'); return; }
    if (/\b(?:help|what can you do|available commands|command list)\b/.test(text)) { reply('I can change demo settings, read a checklist one item at a time, list available checklists, and play the scripted takeoff callout demo. Say “available checklists” for the list. No simulator or live aircraft data is connected.'); return; }
    if (/\b(?:atc|radio clearance|contact tower|ground frequency)\b/.test(text)) { reply('ATC is outside this copilot’s scope.'); return; }
    if (/\b(?:hello|hi|good morning|good afternoon|how are you|how is it going|how’s it going)\b/.test(text)) { reply('Doing well, Captain. I’m ready when you are.'); return; }
    if (/\b(?:thank you|thanks)\b/.test(text)) { reply('You’re welcome, Captain.'); return; }
    if (/\b(?:acknowledge|acknowledged|check|checked)\b/.test(text)) { cancelWarning(); reply('Acknowledged.'); return; }
    if (/\b(?:stop talking|quiet|cancel speech)\b/.test(text)) { stopSpeech(); reply('Understood.'); return; }
    reply('Say again, please. I didn’t understand that clearly.');
  }
  async function askAI(utterance) {
    $('foPresence').textContent = 'Thinking · AI'; status.textContent = 'Understanding your request…';
    try {
      const response = await fetch('/api/assistant', { method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ utterance, state: { ...state, recognition: undefined, checklistTimer: undefined } }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'AI request failed.');
      const accepted = applyAIDemoAction(data);
      if (!accepted && data.action !== 'none') reply('I’m not sure I understood that setting. Please repeat it.');
      else if (data.action !== 'checklist') reply(data.speech || 'Say again, please.');
      status.textContent = 'AI copilot ready';
    } catch (error) {
      toast(`AI unavailable: ${error.message}. Using local demo commands.`);
      status.textContent = 'Local demo mode';
      handleLocalFallback(utterance);
    } finally { $('foPresence').textContent = 'Ready · English'; }
  }
  function applyAIDemoAction(data) {
    const value = String(data.value || '').trim();
    switch (data.action) {
      case 'set_flaps': {
        const n = /^full$/i.test(value) ? 4 : Number(value);
        if (!Number.isInteger(n) || n < 0 || n > 4) return false;
        state.flaps = n; renderState(); return true;
      }
      case 'set_gear': if (!/^(up|down)$/i.test(value)) return false; state.gear = value.toUpperCase(); renderState(); return true;
      case 'set_heading': if (!/^\d{1,3}$/.test(value) || Number(value) > 360) return false; state.heading = Number(value) % 360; state.lastTarget = 'heading'; renderState(); return true;
      case 'set_altitude': if (!/^\d{1,6}$/.test(value) || Number(value) > 60000) return false; state.altitude = Number(value); state.lastTarget = 'altitude'; renderState(); return true;
      case 'set_speed': if (!/^\d{1,3}$/.test(value) || Number(value) > 450) return false; state.speed = Number(value); state.lastTarget = 'speed'; renderState(); return true;
      case 'set_autopilot': if (!/^(off|ap1|ap2)$/i.test(value)) return false; state.autopilot = value.toUpperCase(); renderState(); return true;
      case 'set_autothrust': if (!/^(on|off)$/i.test(value)) return false; state.autothrust = value.toUpperCase(); renderState(); return true;
      case 'set_spoilers': if (!/^(armed|retracted)$/i.test(value)) return false; state.spoilers = value.toUpperCase(); return true;
      case 'set_apu': if (!/^(on|off)$/i.test(value)) return false; state.apu = value.toUpperCase(); return true;
      case 'set_lights': if (!/^(on|off)$/i.test(value)) return false; state.lights = value.toUpperCase(); return true;
      case 'set_engines': if (!/^(on|off)$/i.test(value)) return false; state.engines = value.toUpperCase(); renderState(); return true;
      case 'set_anti_ice': if (!/^(on|off)$/i.test(value)) return false; state.antiIce = value.toUpperCase(); return true;
      case 'set_seatbelts': if (!/^(on|off)$/i.test(value)) return false; state.seatbelts = value.toUpperCase(); return true;
      case 'set_autobrake': if (!/^(off|low|med|max)$/i.test(value)) return false; state.autobrake = value.toUpperCase(); return true;
      case 'set_qnh': if (!/^\d{3,4}$/.test(value) || Number(value) < 800 || Number(value) > 1100) return false; state.qnh = Number(value); renderState(); return true;
      case 'set_parking_brake': if (!/^(set|released)$/i.test(value)) return false; state.parkingBrake = value.toUpperCase(); return true;
      case 'checklist': if (!data.checklist || !flows[data.checklist]) return false; runChecklist(data.checklist, 'step'); return true;
      case 'none': return true;
      default: return false;
    }
  }
  function handleLocalFallback(raw) {
    const wasEnabled = aiEnabled; aiEnabled = false; suppressNextUserMessage = true;
    handleCommand(raw);
    aiEnabled = wasEnabled;
  }
  function sendText() { const value = input.value.trim(); if (!value) return; input.value = ''; handleCommand(value); }
  $('send').addEventListener('click', sendText);
  input.addEventListener('keydown', event => { if (event.key === 'Enter') sendText(); });
  document.querySelectorAll('.quick button').forEach(button => button.addEventListener('click', () => handleCommand(button.dataset.command)));
  $('voiceSelect').addEventListener('change', () => {
    localStorage.setItem('fo-local-voice', $('voiceSelect').value);
    localStorage.setItem('fo-voice-v2', $('voiceSelect').value);
    const selected = speechSynthesis?.getVoices?.().find(voice => voice.name === $('voiceSelect').value);
    $('voiceHelp').textContent = selected?.localService === false
      ? `Using ${selected.name} (${selected.lang}). This online voice needs internet; reply text may be sent to its speech provider.`
      : `Using ${selected?.name || $('voiceSelect').value} installed on this device. Local voice playback works offline.`;
  });
  $('foRole').value = state.foRole;
  $('foRole').addEventListener('change', event => {
    state.foRole = event.target.value === 'PF' ? 'PF' : 'PM';
    localStorage.setItem('fo-role', state.foRole);
    reply(`Understood. I’m assigned ${state.foRole === 'PF' ? 'Pilot Flying' : 'Pilot Monitoring'} for this sector. You remain in command.`);
  });
  $('speakToggle').addEventListener('change', event => { localStorage.setItem('fo-speak', String(event.target.checked)); if (!event.target.checked) { cancelCalloutSequence(); stopSpeech(); } });
  $('aiToggle').addEventListener('change', event => {
    aiEnabled = event.target.checked && aiConfigured;
    if (event.target.checked && !aiConfigured) { event.target.checked = false; aiEnabled = false; toast('Connect AI with your API key first.'); }
    $('aiStatus').textContent = aiEnabled ? 'Online mode on. Your voice clip, transcript, and demo state go to OpenAI for transcription and command understanding; API usage may cost money.' : (aiConfigured ? 'OpenAI connected for this session. Enable the switch above when you want online voice transcription and command understanding.' : 'Optional. OpenAI account and billing may be required for voice transcription and command understanding.');
  });
  $('saveKey').addEventListener('click', async () => {
    const key = $('apiKey').value.trim(); if (!key) { toast('Paste an API key first.'); return; }
    $('aiStatus').textContent = 'Connecting…';
    try {
      const response = await fetch('/api/config', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ apiKey: key }) });
      const data = await response.json(); if (!response.ok) throw new Error(data.error || 'Could not connect.');
      aiConfigured = true; aiEnabled = true; $('aiToggle').checked = true; $('apiKey').value = '';
      $('aiStatus').textContent = 'Online copilot understanding is on. Voice clips, transcripts, and demo state go to OpenAI; API usage may cost money.';
      toast('AI copilot connected for this session.');
    } catch (error) { $('aiStatus').textContent = error.message; toast(error.message); }
  });
  $('clearKey').addEventListener('click', async () => {
    await fetch('/api/config', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ apiKey: '' }) }).catch(() => {});
    aiConfigured = false; aiEnabled = false; $('aiToggle').checked = false; $('apiKey').value = '';
    $('aiStatus').textContent = 'Disconnected. The key was removed from this app session.'; stopSpeech();
    toast('AI disconnected and key removed from memory.');
  });
  const speakPref = localStorage.getItem('fo-speak'); if (speakPref !== null) $('speakToggle').checked = speakPref === 'true';
  if (window.speechSynthesis) { speechSynthesis.addEventListener('voiceschanged', pickVoice); pickVoice(); }

  let binding = false;
  $('bindButton').addEventListener('click', () => { binding = true; $('bindButton').innerHTML = 'Press a key now…<span>Escape cancels</span>'; toast('Press a key to set push to talk.'); });
  const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  let recognitionLanguage = ['en-US', 'en-GB'].includes(localStorage.getItem('fo-recognition-language'))
    ? localStorage.getItem('fo-recognition-language') : 'en-US';
  $('recognitionLanguage').value = recognitionLanguage;
  $('recognitionLanguage').addEventListener('change', event => {
    recognitionLanguage = event.target.value === 'en-GB' ? 'en-GB' : 'en-US';
    localStorage.setItem('fo-recognition-language', recognitionLanguage);
    if (state.recognition) state.recognition.lang = recognitionLanguage;
    $('voiceHelp').textContent = `Speech recognition set to ${recognitionLanguage === 'en-GB' ? 'British' : 'American'} English. This applies to your next command.`;
  });
  function microphoneError(error) {
    const messages = {
      'not-allowed': 'Microphone permission is blocked. In Edge, allow microphone access for this app, then reopen it.',
      'service-not-allowed': 'Edge blocked its speech service. Check Edge privacy settings and internet access.',
      'audio-capture': 'No microphone is available. Check that Windows sees your microphone.',
      'network': 'Speech recognition could not reach its service. Check your internet connection.',
      'no-speech': 'I did not hear speech. Hold the mic and try again.',
      'language-not-supported': 'English speech recognition is unavailable in this browser.',
      'aborted': 'Listening stopped.'
    };
    return messages[error] || `Microphone error: ${error || 'unknown error'}. Check Edge microphone permission and try again.`;
  }
  async function releaseMicrophone() {
    if (state.mediaStream) { state.mediaStream.getTracks().forEach(track => track.stop()); state.mediaStream = null; }
  }
  async function testMicrophone() {
    status.textContent = 'Checking microphone…'; $('voiceHelp').textContent = 'Allow microphone access if Windows or Edge asks. No audio is recorded or sent.';
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach(track => track.stop()); state.micTestPassed = true;
      status.textContent = 'Microphone ready'; $('voiceHelp').textContent = 'Microphone permission and hardware are working. No command was sent.'; toast('Microphone is ready.');
    } catch (error) {
      const message = error.name === 'NotAllowedError' ? microphoneError('not-allowed') : error.name === 'NotFoundError' ? microphoneError('audio-capture') : `Could not open microphone: ${error.message || error.name}`;
      status.textContent = 'Microphone unavailable'; $('voiceHelp').textContent = message; toast(message);
    }
  }
  async function startListening(test = false) {
    if (state.listening) return;
    state.micTest = false; state.micTestPassed = false; state.voiceError = ''; state.recognitionText = ''; state.recognitionInterim = '';
    cancelCalloutSequence(); stopSpeech();
    status.textContent = 'Opening microphone…'; $('voiceHelp').textContent = 'Starting push-to-talk…';
    if (!test && !(aiEnabled && aiConfigured) && state.recognition) {
      try { state.recognition.start(); }
      catch (error) { const message = error.name === 'NotAllowedError' ? microphoneError('not-allowed') : `Could not start microphone: ${error.message || error.name}`; status.textContent = 'Microphone did not start'; $('voiceHelp').textContent = `${message} Connect online mode for transcription that does not depend on Edge speech recognition.`; toast(message); }
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } });
      if (test) { stream.getTracks().forEach(track => track.stop()); state.micTestPassed = true; status.textContent = 'Microphone ready'; $('voiceHelp').textContent = 'Microphone permission and hardware are working. No audio was recorded or sent.'; return; }
      if (!state.pttHeld) { stream.getTracks().forEach(track => track.stop()); return; }
      state.mediaStream = stream; state.listening = true; mic.classList.add('listening');
      if (aiEnabled && aiConfigured && window.MediaRecorder) {
        const mime = ['audio/webm;codecs=opus', 'audio/webm'].find(type => MediaRecorder.isTypeSupported(type)) || '';
        state.recordedChunks = []; state.recorder = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined);
        state.recorder.ondataavailable = event => { if (event.data?.size) state.recordedChunks.push(event.data); };
        state.recorder.onstop = async () => {
          const blob = new Blob(state.recordedChunks, { type: state.recorder?.mimeType || 'audio/webm' }); state.recordedChunks = [];
          await releaseMicrophone(); mic.classList.remove('listening'); state.listening = false;
          if (!blob.size) { status.textContent = 'No audio captured'; $('voiceHelp').textContent = 'I did not get a recording. Hold the mic a little longer and try again.'; return; }
          status.textContent = 'Transcribing…'; $('foPresence').textContent = 'Understanding · English'; $('voiceHelp').textContent = 'Transcribing your recording…';
          try {
            const response = await fetch('/api/transcribe', { method: 'POST', headers: { 'Content-Type': blob.type || 'audio/webm' }, body: blob });
            const data = await response.json(); if (!response.ok) throw new Error(data.error || 'Transcription failed.');
            const heard = String(data.text || '').trim();
            if (!heard) { status.textContent = 'No speech heard'; $('voiceHelp').textContent = 'I could not make out the recording. Please repeat it.'; return; }
            input.value = ''; $('voiceHelp').textContent = `Heard: “${heard}”`; status.textContent = 'Command received'; handleCommand(heard);
          } catch (error) { status.textContent = 'Transcription unavailable'; $('voiceHelp').textContent = `${error.message} You can type the command or try again.`; toast(error.message); }
        };
        state.recorder.start(); $('foPresence').textContent = 'Listening · English'; status.textContent = 'Listening…'; $('voiceHelp').textContent = 'Recording on this device. Release the mic to transcribe with online mode.';
      } else if (state.recognition) {
        try { state.recognition.start(); } catch (error) { await releaseMicrophone(); state.listening = false; mic.classList.remove('listening'); const message = error.name === 'NotAllowedError' ? microphoneError('not-allowed') : `Could not start microphone: ${error.message || error.name}`; status.textContent = 'Microphone did not start'; $('voiceHelp').textContent = `${message} Connect online mode for transcription that does not depend on Edge speech recognition.`; toast(message); }
      } else {
        await releaseMicrophone(); state.listening = false; mic.classList.remove('listening');
        const message = 'Microphone opened, but speech recognition is unavailable. Connect online mode for reliable English transcription.'; status.textContent = 'Recognition unavailable'; $('voiceHelp').textContent = message;
      }
    } catch (error) {
      state.listening = false; mic.classList.remove('listening');
      const message = error.name === 'NotAllowedError' ? microphoneError('not-allowed') : error.name === 'NotFoundError' ? microphoneError('audio-capture') : error.name === 'NotReadableError' ? 'The microphone is busy or unavailable. Close other apps using it and try again.' : `Could not open microphone: ${error.message || error.name}`;
      status.textContent = 'Microphone did not start'; $('voiceHelp').textContent = message; toast(message);
    }
  }
  function completeRecognizedSpeech() {
    const utterance = [state.recognitionText, state.recognitionInterim].filter(Boolean).join(' ').trim();
    state.recognitionText = ''; state.recognitionInterim = '';
    if (utterance && !state.voiceError) { input.value = ''; $('voiceHelp').textContent = `Heard: ${utterance}`; handleCommand(utterance); status.textContent = 'Command received'; }
    else status.textContent = state.voiceError ? 'Recognition unavailable' : 'Voice ready';
  }
  function stopListening() {
    state.pttHeld = false;
    if (state.voiceStartTimer) { clearTimeout(state.voiceStartTimer); state.voiceStartTimer = null; }
    if (state.recorder && state.recorder.state === 'recording') { try { state.recorder.stop(); } catch (_) { } return; }
    if (state.recognition && state.listening) { try { state.recognition.stop(); } catch (_) { } }
    else if (state.recognition && (state.recognitionText.trim() || state.recognitionInterim.trim())) { $('foPresence').textContent = 'Ready · English'; completeRecognizedSpeech(); }
  }
  if (Recognition) {
    const recognition = new Recognition(); recognition.lang = recognitionLanguage; recognition.interimResults = true; recognition.continuous = true; recognition.maxAlternatives = 8; state.recognition = recognition;
    recognition.onstart = () => { state.listening = true; mic.classList.add('listening'); $('foPresence').textContent = 'Listening · English'; status.textContent = 'Listening…'; $('voiceHelp').textContent = 'Listening. Speak a short English command.'; };
    recognition.onresult = event => {
      let finalText = '', interim = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const result = event.results[i];
        const candidates = Array.from({ length: result.length || 1 }, (_, index) => result[index]).filter(item => item?.transcript?.trim());
        let chosen = candidates[0];
        const flow = state.checklist;
        if (flow?.waiting && candidates.length > 1) {
          const positive = /^(?:check|checked|correct|right|yes|yeah|yep|yup|affirmative|confirmed|verified|good|looks good|all good|all set|okay|ok|roger|next item|next one|continue|that is correct|that s correct|thats correct|that is right|thats right)$/;
          const negative = /\b(?:no|nope|not correct|incorrect|wrong|negative|not right|not available|not ready|not set|not on|not off|not up|not down|unavailable|does not match)\b/;
          chosen = candidates.find(candidate => {
            const spoken = normalize(candidate.transcript);
            const tokens = spoken.split(/\s+/);
            const expected = flow.currentExpected || [];
            return expected.some(term => term.includes(' ') ? spoken.includes(term) : tokens.includes(term)) || positive.test(spoken) || negative.test(spoken) || /\b(?:repeat|say again|one more time)\b/.test(spoken);
          }) || chosen;
        } else if (candidates.length > 1) {
          const commandWords = /\b(?:flaps?|gear|heading|altitude|flight level|speed|autopilot|autothrust|apu|qnh|autobrake|spoilers?|checklist|checked|lights?|engines?|climb|descend|maintain|brake)\b/;
          const score = candidate => {
            const spoken = normalize(candidate.transcript);
            return (candidate.confidence || 0) + (commandWords.test(spoken) ? 0.06 : 0) + (/\b(?:set|make that|turn|arm|disarm|start|stop|run|read|check)\b/.test(spoken) ? 0.02 : 0);
          };
          chosen = [...candidates].sort((a, b) => score(b) - score(a))[0];
        }
        const recognized = chosen?.transcript?.trim() || '';
        if (result.isFinal) finalText += `${finalText ? ' ' : ''}${recognized}`;
        else interim += `${interim ? ' ' : ''}${recognized}`;
      }
      if (finalText.trim()) state.recognitionText = [state.recognitionText, finalText.trim()].filter(Boolean).join(' ');
      state.recognitionInterim = interim.trim();
      if (interim) { input.value = [state.recognitionText, interim].filter(Boolean).join(' '); $('voiceHelp').textContent = `Hearing: ${input.value}`; }
      else if (finalText.trim()) { input.value = state.recognitionText; $('voiceHelp').textContent = `Heard: ${state.recognitionText}`; }
    };
    recognition.onerror = event => {
      if (event.error === 'no-speech' && state.pttHeld) { status.textContent = 'Listening…'; $('voiceHelp').textContent = 'Still listening. Keep holding the mic and say your command.'; return; }
      state.voiceError = microphoneError(event.error); status.textContent = `Mic: ${event.error}`;
      $('voiceHelp').textContent = `${state.voiceError} Connect online mode for transcription that does not depend on Edge speech recognition.`;
      if (event.error !== 'aborted') toast(state.voiceError);
    };
    recognition.onend = () => {
      state.listening = false; mic.classList.remove('listening');
      if (state.pttHeld && !state.voiceError) {
        if (state.recognitionInterim) { state.recognitionText = [state.recognitionText, state.recognitionInterim].filter(Boolean).join(' '); state.recognitionInterim = ''; }
        status.textContent = 'Listening…'; $('foPresence').textContent = 'Listening · English';
        state.voiceStartTimer = setTimeout(() => {
          state.voiceStartTimer = null;
          if (state.pttHeld) { try { recognition.start(); } catch (_) { status.textContent = 'Listening paused'; } }
          else { $('foPresence').textContent = 'Ready · English'; completeRecognizedSpeech(); }
        }, 140);
        return;
      }
      $('foPresence').textContent = 'Ready · English'; completeRecognizedSpeech();
    };
  }
  mic.addEventListener('pointerdown', event => { event.preventDefault(); state.pttHeld = true; try { mic.setPointerCapture(event.pointerId); } catch (_) { } startListening(); });
  mic.addEventListener('pointerup', stopListening); mic.addEventListener('pointercancel', stopListening); mic.addEventListener('lostpointercapture', stopListening);
  status.textContent = 'Voice ready'; $('voiceHelp').textContent = 'Hold the mic or push-to-talk key while speaking.';
  $('testMic').addEventListener('click', testMicrophone);
  $('testVoice').addEventListener('click', () => {
    if (!$('speakToggle').checked) { $('voiceHelp').textContent = 'Turn on spoken replies first.'; return; }
    state.ttsTest = true; $('speechStatus').textContent = 'Starting voice test…'; $('voiceHelp').textContent = 'Testing the selected English voice.';
    speak('Captain, flaps one. Heading two four zero set. Gear down.', { callout: true });
  });
  window.addEventListener('keydown', event => {
    if (binding) {
      event.preventDefault(); binding = false;
      if (event.code !== 'Escape') { state.bind = event.code; localStorage.setItem('fo-bind', state.bind); renderState(); toast('Push-to-talk bind updated.'); }
      $('bindButton').innerHTML = 'Change keyboard bind<span>Choose a key to hold while speaking</span>'; return;
    }
    const tag = document.activeElement?.tagName;
    if (event.code === state.bind && !event.repeat && !['INPUT', 'TEXTAREA', 'SELECT'].includes(tag)) { event.preventDefault(); state.pttHeld = true; startListening(); }
  });
  window.addEventListener('keyup', event => { if (event.code === state.bind) stopListening(); });
  $('takeoffDemo').addEventListener('click', calloutSequence);
  $('warningDemo').addEventListener('click', triggerWarning);
  $('resetDemo').addEventListener('click', () => {
    if (state.checklistTimer) clearTimeout(state.checklistTimer); cancelWarning(); state.checklist = null;
    cancelCalloutSequence(); Object.assign(state, { flaps: 0, gear: 'DOWN', heading: 0, altitude: 0, speed: 0, qnh: 1013, autopilot: 'OFF', autothrust: 'OFF', spoilers: 'RETRACTED', lights: 'OFF', apu: 'OFF', engines: 'OFF', antiIce: 'OFF', seatbelts: 'OFF', autobrake: 'OFF', parkingBrake: 'SET', phase: 'PARKED', lastTarget: null });
    $('progress').style.width = '9%'; renderState(); renderChecklist(); stopSpeech(); toast('Demo reset.');
  });
  renderState();
  initStarfield();
  addMessage('First Officer', 'First Officer ready. Demo mode only. Hold push-to-talk to issue a command.');
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});
})();
