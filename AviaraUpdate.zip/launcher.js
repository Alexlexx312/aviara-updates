(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  let mode = 'login';
  let currentUser = null;
  function message(element, text, kind = 'error') {
    element.textContent = text; element.className = `message ${kind}`;
  }
  function clearMessage(element) { element.textContent = ''; element.className = 'message'; }
  async function request(path, options = {}) {
    const response = await fetch(path, { ...options, headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }, cache: 'no-store' });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || `Request failed (${response.status}).`);
    return data;
  }
  function showMode(next) {
    mode = next;
    $('loginTab').setAttribute('aria-selected', String(mode === 'login'));
    $('registerTab').setAttribute('aria-selected', String(mode === 'register'));
    $('authTitle').textContent = mode === 'login' ? 'Sign in' : 'Create account';
    $('authSubtitle').textContent = mode === 'login' ? 'Sign in with the account linked to your license.' : 'A license key from the administrator is required to register.';
    $('keyLabel').classList.toggle('hidden', mode !== 'register');
    $('licenseKey').required = mode === 'register';
    $('password').autocomplete = mode === 'login' ? 'current-password' : 'new-password';
    $('submitAuth').textContent = mode === 'login' ? 'Sign in' : 'Create account and activate key';
    clearMessage($('authMessage'));
  }
  function dateLabel(value) {
    if (!value) return 'No license has been activated.';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return 'License expiry unavailable.';
    const remaining = Math.max(0, Math.ceil((date.getTime() - Date.now()) / 86_400_000));
    return `Expires ${date.toLocaleString()} · ${remaining} day${remaining === 1 ? '' : 's'} remaining`;
  }
  function renderUser(user) {
    currentUser = user;
    $('authCard').classList.add('hidden'); $('dashboard').classList.remove('hidden');
    $('accountEmail').textContent = user.email;
    $('accountRole').textContent = user.role === 'admin' ? 'Administrator account' : 'First Officer account';
    const allowed = user.active || user.role === 'admin';
    $('licenseStatus').textContent = allowed ? 'Active' : 'Inactive';
    $('licenseStatus').classList.toggle('off', !allowed);
    $('licenseExpiry').textContent = user.role === 'admin' ? 'Administrator access' : dateLabel(user.licenseExpiresAt);
    $('launch').disabled = !allowed;
    $('adminPanel').classList.toggle('hidden', user.role !== 'admin');
    $('adminShortcut').classList.toggle('hidden', user.role !== 'admin');
    if (user.role === 'admin') {
      loadAdmin();
      if (new URLSearchParams(location.search).get('view') === 'admin') requestAnimationFrame(() => $('adminPanel').scrollIntoView({ behavior: 'smooth', block: 'start' }));
    }
    if (!user.active && user.role !== 'admin') message($('dashboardMessage'), 'Your license is inactive. Redeem a new key to unlock the demo.', 'error');
    else clearMessage($('dashboardMessage'));
  }
  async function loadSession() {
    try { const data = await request('/api/license/me'); renderUser(data.user); }
    catch { $('dashboard').classList.add('hidden'); $('authCard').classList.remove('hidden'); }
  }
  $('loginTab').addEventListener('click', () => showMode('login'));
  $('registerTab').addEventListener('click', () => showMode('register'));
  $('authForm').addEventListener('submit', async event => {
    event.preventDefault(); clearMessage($('authMessage'));
    const button = $('submitAuth'); button.disabled = true;
    try {
      const data = await request(`/api/license/${mode}`, { method: 'POST', body: JSON.stringify({
        email: $('email').value, password: $('password').value,
        licenseKey: $('licenseKey').value, remember: $('remember').checked
      }) });
      renderUser(data.user);
    } catch (error) { message($('authMessage'), error.message); }
    finally { button.disabled = false; }
  });
  $('logout').addEventListener('click', async () => {
    try { await request('/api/license/logout', { method: 'POST', body: '{}' }); } catch (_) { }
    currentUser = null; $('dashboard').classList.add('hidden'); $('authCard').classList.remove('hidden'); showMode('login');
  });
  $('adminShortcut').addEventListener('click', () => {
    if (currentUser?.role === 'admin') $('adminPanel').scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
  $('passwordForm').addEventListener('submit', async event => {
    event.preventDefault(); clearMessage($('passwordMessage')); $('changePassword').disabled = true;
    try {
      await request('/api/license/password/change', { method: 'POST', body: JSON.stringify({ currentPassword: $('currentPassword').value, newPassword: $('newPassword').value }) });
      $('passwordForm').reset(); message($('passwordMessage'), 'Password updated.', 'ok');
    } catch (error) { message($('passwordMessage'), error.message); }
    finally { $('changePassword').disabled = false; }
  });
  $('launch').addEventListener('click', () => { if (currentUser?.active || currentUser?.role === 'admin') location.href = '/app'; });
  $('redeem').addEventListener('click', async () => {
    clearMessage($('dashboardMessage')); $('redeem').disabled = true;
    try { await request('/api/license/redeem', { method: 'POST', body: JSON.stringify({ licenseKey: $('redeemKey').value }) }); $('redeemKey').value = ''; await loadSession(); message($('dashboardMessage'), 'License activated.', 'ok'); }
    catch (error) { message($('dashboardMessage'), error.message); }
    finally { $('redeem').disabled = false; }
  });
  $('keyForm').addEventListener('submit', async event => {
    event.preventDefault(); clearMessage($('adminMessage')); $('keyForm').querySelector('button').disabled = true;
    try {
      const data = await request('/api/license/admin/keys', { method: 'POST', body: JSON.stringify({ durationDays: Number($('durationDays').value) }) });
      $('newKey').textContent = data.key; $('keyResult').classList.remove('hidden'); message($('adminMessage'), `Created a ${data.durationDays}-day key. Copy it now; its full value will not be shown again.`, 'ok'); await loadAdmin();
    } catch (error) { message($('adminMessage'), error.message); }
    finally { $('keyForm').querySelector('button').disabled = false; }
  });
  $('copyKey').addEventListener('click', async () => {
    try { await navigator.clipboard.writeText($('newKey').textContent); message($('adminMessage'), 'Key copied to clipboard.', 'ok'); }
    catch { message($('adminMessage'), 'Could not copy automatically. Select and copy the key above.', 'error'); }
  });
  function renderTable(headers, rows, empty) {
    if (!rows.length) return `<p class="small" style="padding:12px">${empty}</p>`;
    return `<table><thead><tr>${headers.map(header => `<th>${header}</th>`).join('')}</tr></thead><tbody>${rows.join('')}</tbody></table>`;
  }
  function esc(value) { const element = document.createElement('span'); element.textContent = String(value ?? ''); return element.innerHTML; }
  async function loadAdmin() {
    try {
      const data = await request('/api/license/admin/overview');
      const users = data.users.map(user => {
        const expiry = user.license_expires_at ? new Date(user.license_expires_at) : null;
        const active = expiry && expiry > new Date() && !user.disabled_at;
        const days = active ? Math.ceil((expiry.getTime() - Date.now()) / 86_400_000) : 0;
        const status = active ? `<span class="pill">Active · ${days}d</span>` : '<span class="pill off">Inactive</span>';
        return `<tr><td>${esc(user.email)}</td><td>${esc(new Date(user.created_at).toLocaleDateString())}</td><td>${status}</td><td>${user.redeemed_at ? esc(new Date(user.redeemed_at).toLocaleString()) : '—'}</td><td>${expiry ? esc(expiry.toLocaleString()) : '—'}</td><td>${active ? `<button class="danger revoke" data-id="${Number(user.id)}">Revoke</button>` : '—'}</td></tr>`;
      });
      $('usersTable').innerHTML = renderTable(['Account','Created','License','Redeemed','Expires','Action'], users, 'No registered accounts yet.');
      const keys = data.keys.map(key => {
        const status = key.revoked_at ? '<span class="pill off">Revoked</span>' : key.redeemed_at ? '<span class="pill">Redeemed</span>' : '<span class="pill">Unused</span>';
        const expires = key.expires_at ? new Date(key.expires_at).toLocaleString() : 'Starts at activation';
        const redeemed = key.redeemed_at ? new Date(key.redeemed_at).toLocaleString() : '—';
        return `<tr><td>••••••-${esc(key.key_hint)}</td><td>${Number(key.duration_days)} days</td><td>${status}</td><td>${esc(key.redeemed_email || '—')}</td><td>${esc(redeemed)}</td><td>${esc(expires)}</td></tr>`;
      });
      $('keysTable').innerHTML = renderTable(['Key','Duration','Status','Redeemed by','Redeemed','Expiry'], keys, 'No keys generated yet.');
      document.querySelectorAll('.revoke').forEach(button => button.addEventListener('click', async () => {
        if (!confirm('Revoke this account’s active licenses?')) return;
        try { await request('/api/license/admin/users/revoke', { method: 'POST', body: JSON.stringify({ userId: Number(button.dataset.id) }) }); await loadAdmin(); message($('adminMessage'), 'Active licenses revoked.', 'ok'); }
        catch (error) { message($('adminMessage'), error.message); }
      }));
    } catch (error) { message($('adminMessage'), error.message); }
  }
  let availableUpdate = false;
  async function checkForUpdates(showErrors = false) {
    const panel = $('updatePanel'); const check = $('checkUpdates');
    check.disabled = true;
    try {
      const data = await request('/api/update/check');
      if (!data.configured) { panel.classList.add('hidden'); return; }
      panel.classList.remove('hidden');
      availableUpdate = Boolean(data.available);
      $('updateTitle').textContent = availableUpdate ? `Aviara ${data.latestVersion} is available` : `Aviara is up to date · ${data.currentVersion}`;
      $('updateDetails').textContent = availableUpdate
        ? `${data.notes ? data.notes.slice(0, 500) + ' · ' : ''}Download and prepare it now; it will apply the next time you open Aviara.`
        : 'The launcher will check again when it starts.';
      $('downloadUpdate').classList.toggle('hidden', !availableUpdate);
    } catch (error) {
      if (showErrors) {
        panel.classList.remove('hidden'); availableUpdate = false; $('downloadUpdate').classList.add('hidden');
        $('updateTitle').textContent = 'Could not check for updates'; $('updateDetails').textContent = error.message;
      } else panel.classList.add('hidden');
    } finally { check.disabled = false; }
  }
  $('checkUpdates').addEventListener('click', () => checkForUpdates(true));
  $('downloadUpdate').addEventListener('click', async () => {
    const button = $('downloadUpdate'); button.disabled = true;
    $('updateTitle').textContent = 'Downloading and verifying update…';
    try {
      const data = await request('/api/update/download', { method: 'POST', body: '{}' });
      availableUpdate = false; button.classList.add('hidden');
      $('updateTitle').textContent = `Aviara ${data.version} is ready`;
      $('updateDetails').textContent = 'Close Aviara and open it again from its shortcut. The update will apply automatically; you do not need to download or install the launcher again.';
    } catch (error) {
      $('updateTitle').textContent = 'Update was not installed'; $('updateDetails').textContent = error.message;
    } finally { button.disabled = false; }
  });
  request('/api/license/config').then(config => {
    if (!config.configured) message($('authMessage'), 'Online account service is not configured yet. The administrator must deploy it before accounts and keys can be used.');
  }).catch(() => {});
  checkForUpdates(false);
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});
  showMode('login'); loadSession();
})();
