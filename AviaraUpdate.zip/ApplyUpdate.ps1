param(
  [Parameter(Mandatory=$true)][string]$UpdateDir,
  [Parameter(Mandatory=$true)][string]$InstallDir
)
$ErrorActionPreference = 'Stop'
$updateRoot = [System.IO.Path]::GetFullPath($UpdateDir)
$installRoot = [System.IO.Path]::GetFullPath($InstallDir)
$pendingPath = Join-Path $updateRoot 'pending.json'
$archivePath = Join-Path $updateRoot 'pending.zip'
if (-not (Test-Path -LiteralPath $pendingPath) -or -not (Test-Path -LiteralPath $archivePath)) { exit 0 }
$pending = Get-Content -LiteralPath $pendingPath -Raw | ConvertFrom-Json
if ($pending.archive -ne 'pending.zip' -or $pending.sha256 -notmatch '^[a-fA-F0-9]{64}$') { throw 'Invalid pending Aviara update.' }
$hash = (Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash
if ($hash -ne $pending.sha256) { throw 'Aviara update integrity check failed. The current version was kept.' }
$allowed = @('app-version.json','index.html','app.js','server.mjs','launcher.html','launcher.js','sw.js','manifest.webmanifest','update-config.json','assets/icon.svg','ApplyUpdate.ps1','StopAviaraServer.ps1','Install.cmd','CreateShortcut.vbs')
$staging = Join-Path $updateRoot ('staging-' + [guid]::NewGuid().ToString('N'))
[void](New-Item -ItemType Directory -Path $staging)
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$archive = [System.IO.Compression.ZipFile]::OpenRead($archivePath)
try {
  foreach ($entry in $archive.Entries) {
    if ($entry.FullName -notin $allowed) { continue }
    $destination = [System.IO.Path]::GetFullPath((Join-Path $staging $entry.FullName))
    if (-not $destination.StartsWith($staging + [System.IO.Path]::DirectorySeparatorChar, [System.StringComparison]::OrdinalIgnoreCase)) { throw 'Unsafe file path in update package.' }
    $parent = Split-Path -Parent $destination
    [void](New-Item -ItemType Directory -Path $parent -Force)
    $input = $entry.Open()
    try {
      $output = [System.IO.File]::Create($destination)
      try { $input.CopyTo($output) } finally { $output.Dispose() }
    } finally { $input.Dispose() }
  }
} finally { $archive.Dispose() }
foreach ($required in @('app-version.json','index.html','app.js','server.mjs','launcher.html','launcher.js','sw.js')) {
  if (-not (Test-Path -LiteralPath (Join-Path $staging $required))) { throw "Update package is missing $required." }
}
$backup = Join-Path $updateRoot ('backup-' + [guid]::NewGuid().ToString('N'))
[void](New-Item -ItemType Directory -Path $backup)
$changed = @()
try {
  foreach ($relative in $allowed | Where-Object { $_ -ne 'app-version.json' }) {
    $source = Join-Path $staging $relative
    if (Test-Path -LiteralPath $source) {
      $destination = Join-Path $installRoot $relative
      [void](New-Item -ItemType Directory -Path (Split-Path -Parent $destination) -Force)
      if (Test-Path -LiteralPath $destination) {
        $backupPath = Join-Path $backup $relative
        [void](New-Item -ItemType Directory -Path (Split-Path -Parent $backupPath) -Force)
        Copy-Item -LiteralPath $destination -Destination $backupPath -Force
      }
      Copy-Item -LiteralPath $source -Destination $destination -Force
      $changed += $relative
    }
  }
  $versionSource = Join-Path $staging 'app-version.json'
  $versionDestination = Join-Path $installRoot 'app-version.json'
  if (Test-Path -LiteralPath $versionDestination) { Copy-Item -LiteralPath $versionDestination -Destination (Join-Path $backup 'app-version.json') -Force }
  Copy-Item -LiteralPath $versionSource -Destination $versionDestination -Force
} catch {
  foreach ($relative in $changed) {
    $backupPath = Join-Path $backup $relative
    $destination = Join-Path $installRoot $relative
    if (Test-Path -LiteralPath $backupPath) { Copy-Item -LiteralPath $backupPath -Destination $destination -Force }
  }
  $oldVersion = Join-Path $backup 'app-version.json'
  if (Test-Path -LiteralPath $oldVersion) { Copy-Item -LiteralPath $oldVersion -Destination (Join-Path $installRoot 'app-version.json') -Force }
  throw
}
Remove-Item -LiteralPath $archivePath,$pendingPath -Force
Remove-Item -LiteralPath $staging,$backup -Recurse -Force
Write-Host ('Aviara updated to version ' + $pending.version)
