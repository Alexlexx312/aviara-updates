@echo off
setlocal
set "DEST=%LOCALAPPDATA%\FirstOfficerDemo"
set "MENU=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Aviara.lnk"
set "OLD_MENU=%APPDATA%\Microsoft\Windows\Start Menu\Programs\First Officer Demo.lnk"
if exist "%OLD_MENU%" del /q "%OLD_MENU%"
if not exist "%DEST%" mkdir "%DEST%"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0StopAviaraServer.ps1" -InstallDir "%DEST%"
if errorlevel 1 (
  echo Could not stop the existing Aviara server. Close Aviara and retry the update.
  pause
  exit /b 1
)
robocopy "%~dp0" "%DEST%" /E /NFL /NDL /NJH /NJS /NC /NS >nul
if errorlevel 8 (
  echo Could not copy the app files. Please extract the ZIP again and retry.
  pause
  exit /b 1
)
cscript //nologo "%DEST%\CreateShortcut.vbs" "%MENU%" "%DEST%"
if errorlevel 1 (
  echo App installed to %DEST%, but the Start menu shortcut could not be created.
  pause
  exit /b 1
)
echo Aviara is installed. Opening it now.
start "" "%DEST%\Launch.cmd"
endlocal
