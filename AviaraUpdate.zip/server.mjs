import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import os from 'node:os';
import { createHash } from 'node:crypto';
import { mkdir, readFile, rename, unlink, writeFile } from 'node:fs/promises';

const root = path.dirname(fileURLToPath(import.meta.url));
const versionInfo = JSON.parse(await readFile(path.join(root, 'app-version.json'), 'utf8'));
const appVersion = String(versionInfo.version || '0.0.0');
const files = new Map([
  ['/', ['launcher.html', 'text/html; charset=utf-8']], ['/launcher.html', ['launcher.html', 'text/html; charset=utf-8']],
  ['/launcher.js', ['launcher.js', 'text/javascript; charset=utf-8']],
  ['/app.js', ['app.js', 'text/javascript; charset=utf-8']], ['/sw.js', ['sw.js', 'text/javascript; charset=utf-8']],
  ['/manifest.webmanifest', ['manifest.webmanifest', 'application/manifest+json; charset=utf-8']],
  ['/assets/icon.svg', ['assets/icon.svg', 'image/svg+xml; charset=utf-8']]
]);
let licenseApiBase = '';
try {
  const config = JSON.parse(await readFile(path.join(root, 'license-config.json'), 'utf8'));
  const candidate = String(config.apiBase || '').trim().replace(/\/+$/, '');
  if (candidate.startsWith('https://') || /^http:\/\/(127\.0\.0\.1|localhost)(:\d+)?$/i.test(candidate)) licenseApiBase = candidate;
} catch (_) { }
let updateConfig = { githubOwner: '', githubRepo: '', updateAssetName: 'AviaraUpdate.zip' };
try {
  const config = JSON.parse(await readFile(path.join(root, 'update-config.json'), 'utf8'));
  updateConfig = { ...updateConfig, ...config };
} catch (_) { }

function versionParts(value) {
  const match = /^v?(\d+)\.(\d+)\.(\d+)(?:[-+][0-9A-Za-z.-]+)?$/.exec(String(value || ''));
  return match ? match.slice(1, 4).map(Number) : null;
}
function versionIsNewer(candidate, current) {
  const next = versionParts(candidate); const installed = versionParts(current);
  if (!next || !installed) return false;
  for (let i = 0; i < 3; i++) { if (next[i] !== installed[i]) return next[i] > installed[i]; }
  return false;
}
function updateRepository() {
  const owner = String(updateConfig.githubOwner || '').trim();
  const repo = String(updateConfig.githubRepo || '').trim();
  if (!/^[A-Za-z0-9-]{1,39}$/.test(owner) || !/^[A-Za-z0-9._-]{1,100}$/.test(repo)) return null;
  return { owner, repo };
}
async function latestUpdate() {
  const repository = updateRepository();
  if (!repository) return { configured: false, currentVersion: appVersion, available: false };
  const api = `https://api.github.com/repos/${repository.owner}/${repository.repo}/releases/latest`;
  const response = await fetch(api, { headers: { Accept: 'application/vnd.github+json', 'X-GitHub-Api-Version': '2022-11-28', 'User-Agent': 'Aviara-Launcher' }, signal: AbortSignal.timeout(12000) });
  if (!response.ok) throw Object.assign(new Error(response.status === 404 ? 'Aviara update releases are not published yet.' : `Update check failed (${response.status}).`), { status: 502 });
  const release = await response.json();
  const assetName = String(updateConfig.updateAssetName || 'AviaraUpdate.zip');
  const asset = Array.isArray(release.assets) ? release.assets.find(item => item.name === assetName && item.state === 'uploaded') : null;
  const tag = String(release.tag_name || '');
  const assetUrl = asset ? new URL(asset.browser_download_url) : null;
  const expectedAssetPrefix = `/${repository.owner}/${repository.repo}/releases/download/`;
  const validUrl = assetUrl && assetUrl.protocol === 'https:' && assetUrl.hostname === 'github.com' && assetUrl.pathname.toLowerCase().startsWith(expectedAssetPrefix.toLowerCase());
  const digest = String(asset?.digest || '');
  if (!versionParts(tag) || !asset || !validUrl || !/^sha256:[a-f0-9]{64}$/i.test(digest) || !Number.isSafeInteger(asset.size) || asset.size < 1 || asset.size > 100 * 1024 * 1024) {
    throw Object.assign(new Error('The latest Aviara release is missing a valid update archive or SHA-256 digest.'), { status: 502 });
  }
  return {
    configured: true, currentVersion: appVersion, latestVersion: tag.replace(/^v/, ''),
    available: versionIsNewer(tag, appVersion), notes: String(release.body || '').slice(0, 2000),
    assetUrl: asset.browser_download_url, sha256: digest.slice('sha256:'.length), size: asset.size
  };
}
async function downloadLatestUpdate() {
  const update = await latestUpdate();
  if (!update.configured) throw Object.assign(new Error('Automatic updates are not configured yet.'), { status: 503 });
  if (!update.available) throw Object.assign(new Error('Aviara is already up to date.'), { status: 409 });
  const response = await fetch(update.assetUrl, { headers: { 'User-Agent': 'Aviara-Launcher' }, signal: AbortSignal.timeout(90000) });
  if (!response.ok) throw Object.assign(new Error(`Update download failed (${response.status}).`), { status: 502 });
  const finalUrl = new URL(response.url);
  if (finalUrl.protocol !== 'https:' || !(finalUrl.hostname === 'github.com' || finalUrl.hostname.endsWith('.githubusercontent.com'))) {
    throw Object.assign(new Error('Update download was redirected to an untrusted host.'), { status: 502 });
  }
  const declaredLength = Number(response.headers.get('content-length') || 0);
  const maxBytes = 100 * 1024 * 1024;
  if (declaredLength > maxBytes) throw Object.assign(new Error('Aviara update archive is too large.'), { status: 413 });
  const reader = response.body?.getReader();
  if (!reader) throw Object.assign(new Error('Update download returned no file.'), { status: 502 });
  const chunks = []; let total = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > maxBytes) { await reader.cancel(); throw Object.assign(new Error('Aviara update archive is too large.'), { status: 413 }); }
      chunks.push(Buffer.from(value));
    }
  } finally { reader.releaseLock(); }
  const archive = Buffer.concat(chunks, total);
  if (!archive.length) throw Object.assign(new Error('Aviara update archive is empty.'), { status: 413 });
  const actualDigest = createHash('sha256').update(archive).digest('hex');
  if (actualDigest !== update.sha256) throw Object.assign(new Error('Aviara update integrity check failed. The current version was kept.'), { status: 502 });
  const updateDir = path.join(process.env.LOCALAPPDATA || os.homedir(), 'Aviara', 'Updates');
  await mkdir(updateDir, { recursive: true });
  const archivePath = path.join(updateDir, 'pending.zip');
  const pendingPath = path.join(updateDir, 'pending.json');
  const temporaryPath = path.join(updateDir, 'pending.tmp');
  await writeFile(temporaryPath, archive, { flag: 'w' });
  await unlink(archivePath).catch(() => {});
  await rename(temporaryPath, archivePath);
  await writeFile(pendingPath, JSON.stringify({ version: update.latestVersion, sha256: update.sha256, archive: 'pending.zip' }), 'utf8');
  return { version: update.latestVersion, restartRequired: true };
}
let apiKey = '';
const limit = 12000;
function send(response, status, data, type = 'application/json; charset=utf-8') {
  response.writeHead(status, { 'Content-Type': type, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
  response.end(data);
}
async function bodyJson(request) {
  let raw = '';
  for await (const chunk of request) { raw += chunk; if (raw.length > limit) throw new Error('Request too large'); }
  return JSON.parse(raw || '{}');
}
async function bodyBuffer(request, maxBytes = 20 * 1024 * 1024) {
  const chunks = []; let size = 0;
  for await (const chunk of request) { size += chunk.length; if (size > maxBytes) throw new Error('Request too large'); chunks.push(chunk); }
  return Buffer.concat(chunks, size);
}
function cookieToken(request) {
  const cookie = String(request.headers.cookie || '').split(';').map(value => value.trim()).find(value => value.startsWith('fo_session='));
  return cookie ? decodeURIComponent(cookie.slice('fo_session='.length)) : '';
}
function sessionCookie(token, remember) {
  return `fo_session=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Strict${remember ? '; Max-Age=2592000' : ''}`;
}
async function licenseRequest(pathname, { method = 'GET', token = '', data } = {}) {
  if (!licenseApiBase) throw Object.assign(new Error('The online license service is not configured yet.'), { status: 503 });
  const headers = { Accept: 'application/json' };
  if (token) headers.Authorization = `Bearer ${token}`;
  if (data !== undefined) headers['Content-Type'] = 'application/json';
  const response = await fetch(`${licenseApiBase}${pathname}`, { method, headers, body: data === undefined ? undefined : JSON.stringify(data), signal: AbortSignal.timeout(12000) });
  const payload = await response.json().catch(() => ({}));
  return { status: response.status, payload };
}
function licenseError(response, result) {
  return send(response, result.status, JSON.stringify(result.payload));
}
function readCookiePath(request) {
  const url = new URL(request.url || '/', 'http://127.0.0.1');
  return url.pathname;
}
async function openAI(pathname, payload) {
  if (!apiKey) throw new Error('Add your API key in Settings to enable AI mode.');
  const response = await fetch(`https://api.openai.com/v1/${pathname}`, {
    method: 'POST', headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(payload), signal: AbortSignal.timeout(45000)
  });
  if (!response.ok) {
    const error = await response.json().catch(() => ({}));
    throw new Error(error.error?.message || `AI service returned ${response.status}.`);
  }
  return response;
}
const server = http.createServer(async (request, response) => {
  const pathname = readCookiePath(request);
  try {
    if (request.method === 'GET' && pathname === '/api/update/check') {
      const update = await latestUpdate();
      delete update.assetUrl; delete update.sha256; delete update.size;
      return send(response, 200, JSON.stringify(update));
    }
    if (request.method === 'POST' && pathname === '/api/update/download') {
      const origin = String(request.headers.origin || '');
      if (origin && origin !== 'http://127.0.0.1:8787') return send(response, 403, JSON.stringify({ error: 'Update downloads must be requested by the Aviara launcher.' }));
      const update = await downloadLatestUpdate();
      return send(response, 200, JSON.stringify(update));
    }
    if (request.method === 'GET' && pathname === '/api/license/config') return send(response, 200, JSON.stringify({ configured: Boolean(licenseApiBase) }));
    if (request.method === 'POST' && (pathname === '/api/license/register' || pathname === '/api/license/login')) {
      const data = await bodyJson(request);
      const route = pathname.endsWith('/register') ? '/v1/register' : '/v1/login';
      const result = await licenseRequest(route, { method: 'POST', data });
      if (result.status < 200 || result.status >= 300) return licenseError(response, result);
      const token = String(result.payload.token || '');
      if (!token) return send(response, 502, JSON.stringify({ error: 'The license service did not create a session.' }));
      response.setHeader('Set-Cookie', sessionCookie(token, Boolean(data.remember)));
      delete result.payload.token;
      return send(response, result.status, JSON.stringify(result.payload));
    }
    if (pathname.startsWith('/api/license/')) {
      const token = cookieToken(request);
      const routes = {
        'GET /api/license/me': ['/v1/me', 'GET'],
        'POST /api/license/password/change': ['/v1/password/change', 'POST'],
        'POST /api/license/logout': ['/v1/logout', 'POST'],
        'POST /api/license/redeem': ['/v1/redeem', 'POST'],
        'GET /api/license/admin/overview': ['/v1/admin/overview', 'GET'],
        'POST /api/license/admin/keys': ['/v1/admin/keys', 'POST'],
        'POST /api/license/admin/users/revoke': ['/v1/admin/users/revoke', 'POST']
      };
      const route = routes[`${request.method} ${pathname}`];
      if (!route) return send(response, 404, JSON.stringify({ error: 'Not found.' }));
      const data = route[1] === 'POST' && pathname !== '/api/license/logout' ? await bodyJson(request) : undefined;
      const result = await licenseRequest(route[0], { method: route[1], token, data });
      if (pathname === '/api/license/logout') response.setHeader('Set-Cookie', 'fo_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0');
      return licenseError(response, result);
    }
    if ((request.method === 'GET' && (pathname === '/app' || pathname === '/index.html'))) {
      const result = await licenseRequest('/v1/me', { token: cookieToken(request) });
      if (result.status !== 200 || !(result.payload.user?.active || result.payload.user?.role === 'admin')) {
        response.writeHead(302, { Location: '/', 'Cache-Control': 'no-store' }); response.end(); return;
      }
      const content = await readFile(path.join(root, 'index.html'));
      response.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff',
        'Referrer-Policy': 'no-referrer', 'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; media-src 'self' blob:; connect-src 'self' https: wss:; object-src 'none'; base-uri 'self'; frame-ancestors 'none'",
        'Permissions-Policy': 'microphone=(self)' });
      response.end(content); return;
    }
    if (request.method === 'GET' && pathname === '/api/status') return send(response, 200, JSON.stringify({ configured: Boolean(apiKey) }));
    if (request.method === 'POST' && pathname === '/api/config') {
      const data = await bodyJson(request); const key = String(data.apiKey || '').trim();
      if (key && (!key.startsWith('sk-') || key.length < 20 || key.length > 300)) return send(response, 400, JSON.stringify({ error: 'That does not look like an API key.' }));
      apiKey = key; return send(response, 200, JSON.stringify({ configured: Boolean(apiKey) }));
    }
    if (request.method === 'POST' && pathname === '/api/transcribe') {
      if (!apiKey) return send(response, 401, JSON.stringify({ error: 'Connect online mode with your API key first.' }));
      const audio = await bodyBuffer(request);
      if (!audio.length) return send(response, 400, JSON.stringify({ error: 'No audio was recorded.' }));
      const mime = String(request.headers['content-type'] || 'audio/webm').split(';')[0].slice(0, 80);
      const form = new FormData();
      form.append('file', new Blob([audio], { type: mime }), mime.includes('wav') ? 'command.wav' : 'command.webm');
      form.append('model', 'gpt-4o-mini-transcribe');
      form.append('language', 'en');
      form.append('prompt', 'English FlyByWire A320 cockpit commands and checklist replies. Aviation words: flaps one/two/three/full/zero, gear up/down, heading, altitude, flight level, speed, autothrust, autopilot, APU, QNH, autobrake, anti-ice, parking brake, spoilers, V1, rotate, V2, positive climb. Checklist replies are short and natural: available, ready, set, on, off, checked, check, correct, yes, all good, not available, not ready, not set, not on, not correct, repeat, say again. Common speech-to-text mistakes: available may sound like “a valuable”, “a veilable” or “avail”; flaps may sound like “flap”, “flat” or “flats”; gear may sound like “year” or “ear”; heading may sound like “hedging”, “head in” or “heading bug”; altitude may sound like “attitude”; autopilot may sound like “auto pile it”; autothrust may sound like “auto trust”; autobrake may sound like “auto brake” or “auto break”; QNH may sound like “Q and H”. Recognize spoken number words and common aviation number pronunciations. Preserve negations (not/no/off) and turn direction (left/right). For fast speech, preserve the full instruction including its first and last words; do not truncate it. Transcribe only what was actually said, use context to choose the likely aviation word, and never invent a response.');
      const result = await fetch('https://api.openai.com/v1/audio/transcriptions', { method: 'POST', headers: { Authorization: `Bearer ${apiKey}` }, body: form, signal: AbortSignal.timeout(45000) });
      if (!result.ok) { const error = await result.json().catch(() => ({})); throw new Error(error.error?.message || `Transcription service returned ${result.status}.`); }
      const data = await result.json();
      return send(response, 200, JSON.stringify({ text: String(data.text || '').slice(0, 1200) }));
    }
    if (request.method === 'POST' && pathname === '/api/assistant') {
      const data = await bodyJson(request);
      const utterance = String(data.utterance || '').slice(0, 1200);
      const context = JSON.stringify(data.state || {}).slice(0, 1500);
      if (!utterance) return send(response, 400, JSON.stringify({ error: 'Say or type a command first.' }));
      const result = await openAI('chat/completions', {
        model: 'gpt-4o-mini', temperature: 0.2,
        messages: [
          { role: 'system', content: `You are the user's English-speaking virtual first officer for an FBW A320 DEMO. Understand natural, polite cockpit commands and likely speech-to-text mistakes. Interpret the whole phrase and its context: “year down” can mean “gear down”, “flat's one” can mean “flaps one”, “hedging two four zero” can mean heading 240, “attitude five thousand” can mean altitude 5000, “auto pile it” can mean autopilot, “auto trust” can mean autothrust, and “Q and H” can mean QNH. Ignore harmless filler such as “please” or “can you”, but preserve negations, corrections, and left/right direction. Convert digit-by-digit headings and pressures carefully; a flight level such as three five zero means FL350, while an altitude such as five thousand means 5000 feet. Do not silently change a requested value or guess an ambiguous command; ask one short clarification and return action=none. Sound calm, fluent, concise, and professional; use natural short cockpit readbacks such as “Heading two four zero set”, “Flaps one”, and “Gear down”, with no chatbot filler. The crew position First Officer is separate from the sector role Pilot Flying (PF) or Pilot Monitoring (PM); follow the assigned foRole in the demo state. The user is Captain and remains pilot in command. Act only on clear requests and never claim an action happened on a real aircraft. As PM, support instructions with concise readbacks and reminders; as PF, follow the user's authority and explicit requests. ATC is not connected; never invent clearances, sensor readings, V-speeds, or checklist completion. This is a disconnected demo: actions change only the demo display. Procedures and callout examples are generic demonstrations, not approved FBW/operator SOP. For V1/Rotate/V2/positive-climb callouts, only explain or demonstrate when asked; never trigger from invented flight data. The app handles active checklist replies locally: read only the item name, accept its natural status response or a clear correction, and keep the exchange concise. Never add response-format instructions to checklist speech. Do not skip items. Reply JSON only with keys speech, action, value, mode, checklist. Allowed action values: none,set_flaps,set_gear,set_heading,set_altitude,set_speed,set_autopilot,set_autothrust,set_spoilers,set_apu,set_lights,set_engines,set_anti_ice,set_seatbelts,set_autobrake,set_qnh,set_parking_brake,checklist. value is a short string; mode is step; checklist is one of preflight,before start,after start,taxi,before takeoff,climb,cruise,descent,approach,landing,after landing,shutdown or empty. Use action only for a clear explicit request. For checklist, choose only a named available checklist. Never tell the user you actually moved a real control.` },
          { role: 'user', content: `Current simulated demo state: ${context}\nUser said: ${utterance}` }
        ],
        response_format: { type: 'json_schema', json_schema: { name: 'first_officer_reply', strict: true, schema: {
          type: 'object', additionalProperties: false, required: ['speech', 'action', 'value', 'mode', 'checklist'], properties: {
            speech: { type: 'string' }, action: { type: 'string', enum: ['none','set_flaps','set_gear','set_heading','set_altitude','set_speed','set_autopilot','set_autothrust','set_spoilers','set_apu','set_lights','set_engines','set_anti_ice','set_seatbelts','set_autobrake','set_qnh','set_parking_brake','checklist'] },
            value: { type: 'string' }, mode: { type: 'string', enum: ['full','step'] }, checklist: { type: 'string', enum: ['','preflight','before start','after start','taxi','before takeoff','climb','cruise','descent','approach','landing','after landing','shutdown'] }
          }
        } } }
      });
      const json = await result.json(); const content = json.choices?.[0]?.message?.content;
      if (!content) throw new Error('AI returned an empty response.');
      const parsed = JSON.parse(content);
      if (typeof parsed.speech !== 'string' || parsed.speech.length > 1200) throw new Error('AI response was not valid.');
      return send(response, 200, JSON.stringify(parsed));
    }
    if (request.method !== 'GET') return send(response, 405, JSON.stringify({ error: 'Method not allowed.' }));
    const file = files.get(pathname);
    if (!file) return send(response, 404, 'Not found', 'text/plain; charset=utf-8');
    const content = await readFile(path.join(root, file[0]));
    response.writeHead(200, { 'Content-Type': file[1], 'Cache-Control': pathname === '/sw.js' ? 'no-cache' : 'public, max-age=300',
      'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer',
      'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; media-src 'self' blob:; connect-src 'self' https: wss:; object-src 'none'; base-uri 'self'; frame-ancestors 'none'",
      'Permissions-Policy': 'microphone=(self)' });
    response.end(content);
  } catch (error) {
    const status = error.status || (/Request too large/.test(error.message) ? 413 : (error.message.includes('Connect online mode') ? 401 : 502));
    if (response.headersSent) return response.destroy();
    send(response, status, JSON.stringify({ error: String(error.message || 'Request failed.').slice(0, 500) }));
  }
});
server.on('error', error => { if (error.code === 'EADDRINUSE') process.exit(0); process.exitCode = 1; });
server.listen(8787, '127.0.0.1');
